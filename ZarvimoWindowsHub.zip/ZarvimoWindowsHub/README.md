# Zarvimo Windows Hub

An Android app (Kotlin, Jetpack Compose) that manages Windows `.exe` / `.msi` files and launches them through a
**Wine-based compatibility layer that you supply**, optionally combined with a CPU translator such as Box64.

> **Read this first.** Zarvimo Windows Hub is a front end and process manager. It does not emulate Windows
> itself, it does not bundle Wine, and it has no X server. It does **not** make arbitrary Windows applications run
> on Android, and nothing in the app pretends otherwise. Whether a given program works depends on the program, the
> runtime package you install and your device. The app only ever shows what actually happened (real process
> output, real exit codes, real refusals).

## What is implemented, and what is not

| Area | Status |
|---|---|
| Import `.exe` / `.msi` into private storage, SHA-256, duplicate detection | Implemented |
| Read real file headers: EXE vs DLL vs MSI, CPU (x86 / x64 / ARM64), GUI/console, .NET flag | Implemented (PE/OLE parsing; unit-tested) |
| "Open with" / "Share" of `.exe` / `.msi` from other apps (where the app sends a matching MIME type) | Implemented |
| Install a user-supplied runtime package (tar.xz / tar.gz / tar.bz2 / tar / zip) with safe extraction and manifest validation | Implemented (unit-tested) |
| Environments (Wine prefixes): create, initialize with `wineboot`, settings, delete | Implemented |
| Run a program / install an MSI (`msiexec`) / `winecfg` / `regedit` / runtime version check as real child processes | Implemented |
| Launch pre-checks that refuse impossible launches with a reason (CPU mismatch, no display, missing files) | Implemented (unit-tested) |
| Live output, exit codes, stop, share log; foreground service while processes run | Implemented |
| Device check including a real "can this device execute a binary from app storage?" test | Implemented |
| **Wine / Box64 / FEX binaries** | **Not included.** You provide a runtime package ([format](docs/RUNTIME_FORMAT.md)) |
| **X server / screen output / touch & keyboard input** | **Not included.** Graphical programs need an external Android X server reachable over TCP |
| Audio, controllers, GPU acceleration, DirectX/Vulkan translation | Not included (whatever your runtime provides) |
| Installing Wine Mono, Gecko, VC++ runtimes | Not included (install them yourself inside an environment) |
| Drivers, kernel-mode anti-cheat, DRM-protected software, 16-bit programs | Not supported |
| Google Play distribution | Not possible with this design (see "Architecture limits") |

## How launching works

1. You import a Windows file. The app reads its headers and shows what it is.
2. You install a runtime package. The app extracts it, validates `zarvimo-runtime.json` and checks the files it names.
3. You create an environment (a Wine prefix bound to one runtime) and press **Initialize**. The environment is marked
   initialized only if `wineboot` exits with code 0 **and** Wine wrote `system.reg`.
4. You press **Run** on a library item. The launch planner checks, in order: device ABI vs runtime `hostAbi`;
   program CPU vs the runtime's declared `windowsMachines`; file type; X11 display configured and actually accepting
   TCP connections (for graphical programs); runtime executable present and executable. Any failure is shown with its reason and
   nothing is started.
5. If all checks pass, the app starts the runtime's command as a real child process, streams its output into the
   Sessions tab and records the real exit code.

"The process started" is not "the program works": read the session log.

## Prerequisites

To **build**: a GitHub account (for the Actions build below), or locally JDK 17 and the Android SDK (platform 35, build-tools 35.0.0).

To **use**, beyond installing the APK:

- An Android device whose CPU architecture matches your runtime package (usually ARM64).
- A **runtime package** in the format described in [docs/RUNTIME_FORMAT.md](docs/RUNTIME_FORMAT.md). Building or
  obtaining a working Wine-for-Android package (and Box64/FEX if the device is ARM and the program is x86) is the
  hard part and is not provided here.
- For graphical programs: an Android X server app that accepts **TCP** connections, running before you launch.
  Set the environment's display to `127.0.0.1:0` (TCP port 6000) or whatever that app uses.
  Console programs need no display.

## Building the debug APK with GitHub Actions

You do not need to extract the project ZIP.

1. Create a GitHub repository.
2. Upload this project ZIP (e.g. `ZarvimoWindowsHub.zip`) to the repository **as-is** (repository root is simplest; up to 4 folders deep also works).
3. Upload the workflow separately as `.github/workflows/Android-Build.yml`.
4. Push or run the workflow manually (**Actions → Android Build → Run workflow**).

The workflow locates a ZIP that contains a Gradle project, extracts it into the runner workspace, builds
`assembleDebug` on `ubuntu-latest` (JDK 17, Android SDK from the runner image), uploads
`app-debug.apk` as the artifact **Zarvimo-Windows-Hub-debug-apk**, then runs the unit tests (a test failure is
reported but does not discard the APK). Download the artifact from the run's page.

## Building locally

```
./gradlew assembleDebug          # APK: app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest      # JVM unit tests
```

Requires JDK 17 and an Android SDK with platform 35 (`ANDROID_HOME` or `local.properties` with `sdk.dir=...`).
The first build downloads Gradle 8.10.2 and dependencies.

## Installing and first run

Sideload the APK (allow installation from your file manager or browser). Open **Status** and check "Run-from-storage test".
If it reports **Blocked**, no runtime can ever run on that device/ROM; the rest of the app still works but
launching will fail.

## Architecture limits (please read)

- **ARM phone, x86 program.** Most Windows programs are x86 / x64. On an ARM64 phone they need a CPU translator
  (Box64 or FEX) packaged inside your runtime. Zarvimo does not translate anything itself; it only refuses
  programs whose CPU type your runtime does not declare. ARM64 Windows programs additionally need a Wine build that supports them.
- **64-bit only devices.** Many recent phones dropped 32-bit execution. A 32-bit (`x86`) Windows program then
  depends entirely on whether your runtime can run it (for example Wine's WoW64 mode); declare `x86` in
  `windowsMachines` only if you tested it.
- **Android's execute restriction (W^X).** Android 10+ stops apps that target API 29 or higher from executing files
  stored in their own data folder. Runtimes are executables in app storage, so this app **deliberately targets
  API 28** (`targetSdk = 28` in `app/build.gradle.kts`). Consequences: it is for sideloading, not Google Play, and future
  Android versions may restrict apps with old target levels further. The Status tab tests execution on your
  actual device instead of assuming it works.
- **Resources.** Wine prefixes and runtimes are large (hundreds of MB to several GB). Programs may be slow.
- **No hardware acceleration** is configured by Zarvimo.
- **Background processes.** Stop kills the launched process and runs the runtime's optional `stopCommand`
  (typically `wineserver -k`). Without a suitable `stopCommand`, helper processes such as `wineserver` may linger briefly.

## Licensing

- **Zarvimo Windows Hub source code:** MIT License, see [LICENSE](LICENSE).
- **Libraries used by the app** (Apache-2.0 for AndroidX / Jetpack Compose / Kotlin / kotlinx.coroutines / Apache Commons Compress;
  XZ for Java is public domain): see [NOTICE](NOTICE).
- **Wine** is LGPL-2.1-or-later; **Box64** and **FEX-Emu** have their own open-source licenses. Zarvimo does not
  include them. If *you* package and distribute a runtime, you are responsible for complying with those licenses
  (including offering corresponding source).
- **Windows software** you import remains under its own license. Zarvimo does not provide Windows software,
  Windows licenses, activation bypasses or DRM circumvention, and you are responsible for having the right to use what you import.
- "Windows" is a trademark of Microsoft. This project is not affiliated with or endorsed by Microsoft or the Wine project.

## Troubleshooting

| Symptom | Likely cause and what to do |
|---|---|
| **Run-from-storage test: Blocked** | The ROM forbids executing app-storage files for this app. No runtime can launch. Try another device/ROM. |
| Runtime import: "zarvimo-runtime.json was not found" | The manifest must be at the archive's top level, not inside a subfolder. Repack so it is. |
| Runtime import: "contains x86_64 binaries, but this device supports arm64-v8a" | The package targets another CPU than this device. Use a package built for your ABI. |
| Runtime import: "Zstandard archives are not supported" | Repack as `.tar.xz`, `.tar.gz` or `.zip`. |
| "Unsafe path in archive" | The archive contains absolute paths or `..`; it was refused on purpose. Repack it cleanly. |
| Launch refused: "This needs a graphical display…" | No X11 display set. Open the environment's Settings and set `127.0.0.1:0` (or your X server's address). |
| Launch refused: "Nothing is listening for X11…" | Start your X server app first and make sure it accepts TCP connections on that port. |
| Launch refused: "program is x86-64 but runtime supports only…" | Your runtime does not declare that CPU type. Use a runtime that does (and that actually runs it). |
| Session ends immediately with exit code 126/127 or "error=13" | Permission denied or missing interpreter/loader. The runtime package is incomplete or not executable; check `executables` and the first lines of the script. |
| "error=8 Exec format error" | A binary in the runtime is for a different CPU than the device. |
| Initialize says "wineboot exited normally but Wine did not create system.reg" | The runtime's Wine could not create the prefix. Set WINEDEBUG to `err+all`, initialize again and read the log. |
| .NET program fails | It needs Wine Mono (or a .NET runtime) inside the environment; Zarvimo does not install it. |
| Program starts but shows nothing | Usually the X server isn't showing it, or Wine failed after starting. Read the session log. |
| GitHub Action: "No ZIP archive containing a Gradle project was found" | Upload the project ZIP into the repository (not just inside a release or artifact). |
| GitHub Action: SDK / license errors | Re-run; the workflow accepts licenses and installs platform 35 automatically. If the runner image changed, update the SDK step in the workflow. |
| Gradle: `Unsupported class file major version` | Use JDK 17 when building locally. |

## Project layout

```
app/src/main/java/com/zarvimo/windowshub/
  core/      Pure Kotlin: PE/OLE inspection, runtime manifest, safe archive extraction, launch planner, JSON, parsing
  data/      Library, runtime and environment repositories, device check, private storage
  runtime/   Session manager (real processes) and foreground service
  ui/        Jetpack Compose screens
app/src/test/  JVM unit tests (PE parsing, archive safety, planner rules, real child-process sessions)
docs/RUNTIME_FORMAT.md   Runtime package specification
```

## Verification status of this source

The unit tests (46) cover the core logic and the session manager against real child processes. The Jetpack
Compose UI and Android-specific classes are built by Gradle; they have not been exercised on a physical device with a real Wine runtime by the author of this
source, because no such runtime is bundled. Expect to find and report device-specific issues.
