# Release minification is disabled (see app/build.gradle.kts). Rules kept for completeness.
-dontwarn org.apache.commons.**
-dontwarn org.tukaani.xz.**
