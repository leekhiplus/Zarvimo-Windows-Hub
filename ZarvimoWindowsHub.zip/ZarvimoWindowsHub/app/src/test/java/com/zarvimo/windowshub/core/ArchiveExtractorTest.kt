package com.zarvimo.windowshub.core

import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files

class ArchiveExtractorTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val extractor = ArchiveExtractor(JvmFileOps)

    private class TarBuilder(gzip: Boolean) {
        val bytes = ByteArrayOutputStream()
        private val raw = if (gzip) GzipCompressorOutputStream(bytes) else bytes
        val tar = TarArchiveOutputStream(raw).also { it.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX) }

        fun dir(name: String, mode: Int = 0x1ED) {
            val e = TarArchiveEntry(name.trimEnd('/') + "/")
            e.mode = mode
            tar.putArchiveEntry(e); tar.closeArchiveEntry()
        }

        fun file(name: String, content: String, mode: Int = 0x1A4) {
            val data = content.toByteArray()
            val e = TarArchiveEntry(name)
            e.size = data.size.toLong()
            e.mode = mode
            tar.putArchiveEntry(e); tar.write(data); tar.closeArchiveEntry()
        }

        fun symlink(name: String, target: String) {
            val e = TarArchiveEntry(name, TarArchiveEntry.LF_SYMLINK)
            e.linkName = target
            tar.putArchiveEntry(e); tar.closeArchiveEntry()
        }

        fun hardlink(name: String, target: String) {
            val e = TarArchiveEntry(name, TarArchiveEntry.LF_LINK)
            e.linkName = target
            tar.putArchiveEntry(e); tar.closeArchiveEntry()
        }

        fun finish(): ByteArray {
            tar.finish(); tar.close()
            return bytes.toByteArray()
        }
    }

    private fun extract(bytes: ByteArray, dest: File) = extractor.extract(ByteArrayInputStream(bytes), dest)

    @Test
    fun extractsTarGzWithModesAndSymlinks() {
        val b = TarBuilder(gzip = true)
        b.dir("./bin")
        b.file("./bin/wine", "#!/bin/sh\necho hi\n", mode = 0x1ED) // 0755
        b.file("zarvimo-runtime.json", "{}")
        b.symlink("bin/wine64", "wine") // relative
        b.symlink("lib-abs", "/usr/lib") // absolute symlinks are legitimate in a rootfs
        b.hardlink("bin/wine-hard", "bin/wine")
        val dest = tmp.newFolder("out")
        val r = extract(b.finish(), dest)
        assertTrue(r.files >= 3)
        assertEquals("#!/bin/sh\necho hi\n", File(dest, "bin/wine").readText())
        assertTrue(File(dest, "bin/wine").canExecute())
        assertFalse(File(dest, "zarvimo-runtime.json").canExecute())
        assertTrue(Files.isSymbolicLink(File(dest, "bin/wine64").toPath()))
        assertTrue(File(dest, "bin/wine64").isFile) // resolves through the relative link
        assertTrue(Files.isSymbolicLink(File(dest, "lib-abs").toPath()))
        assertEquals("#!/bin/sh\necho hi\n", File(dest, "bin/wine-hard").readText())
    }

    @Test
    fun extractsPlainTar() {
        val b = TarBuilder(gzip = false)
        b.file("a.txt", "A")
        val dest = tmp.newFolder("out")
        extract(b.finish(), dest)
        assertEquals("A", File(dest, "a.txt").readText())
    }

    @Test
    fun rejectsPathTraversalAndAbsolutePaths() {
        for (name in listOf("../evil.txt", "a/../../evil.txt")) {
            val b = TarBuilder(gzip = true)
            b.file(name, "x")
            val dest = tmp.newFolder()
            try {
                extract(b.finish(), dest)
                fail("should reject $name")
            } catch (_: ArchiveException) {
            }
            assertFalse(File(dest.parentFile, "evil.txt").exists())
        }
    }

    @Test
    fun absoluteEntryNamesStayInsideDestination() {
        // commons-compress strips the leading "/" from tar names, so this must land inside dest (never at /abs).
        val b = TarBuilder(gzip = true)
        b.file("/abs-test-zarvimo/evil.txt", "x")
        val dest = tmp.newFolder("out")
        try {
            extract(b.finish(), dest)
        } catch (_: ArchiveException) {
            // rejecting is also acceptable
        }
        assertFalse(File("/abs-test-zarvimo/evil.txt").exists())
    }

    @Test
    fun rejectsWriteThroughSymlinkThatEscapes() {
        val outside = tmp.newFolder("outside")
        val b = TarBuilder(gzip = true)
        b.symlink("escape", outside.absolutePath)
        b.file("escape/pwned.txt", "x")
        val dest = tmp.newFolder("out")
        try {
            extract(b.finish(), dest)
            fail("should reject write through escaping symlink")
        } catch (_: ArchiveException) {
        }
        assertFalse(File(outside, "pwned.txt").exists())
    }

    @Test
    fun fileReplacingSymlinkDoesNotWriteThroughIt() {
        val outside = tmp.newFolder("outside")
        val victim = File(outside, "victim.txt").apply { writeText("original") }
        val b = TarBuilder(gzip = true)
        b.symlink("link", victim.absolutePath)
        b.file("link", "overwritten?")
        val dest = tmp.newFolder("out")
        extract(b.finish(), dest)
        assertEquals("original", victim.readText())
        assertFalse(Files.isSymbolicLink(File(dest, "link").toPath()))
        assertEquals("overwritten?", File(dest, "link").readText())
    }

    @Test
    fun rejectsHardLinkToMissingTarget() {
        val b = TarBuilder(gzip = false)
        b.hardlink("x", "does-not-exist")
        try {
            extract(b.finish(), tmp.newFolder())
            fail()
        } catch (_: ArchiveException) {
        }
    }

    @Test
    fun extractsZip() {
        val bos = ByteArrayOutputStream()
        ZipArchiveOutputStream(bos).use { z ->
            val e = ZipArchiveEntry("dir/run.sh")
            e.unixMode = 0x1ED or 0x8000
            z.putArchiveEntry(e); z.write("echo".toByteArray()); z.closeArchiveEntry()
            val e2 = ZipArchiveEntry("zarvimo-runtime.json")
            z.putArchiveEntry(e2); z.write("{}".toByteArray()); z.closeArchiveEntry()
        }
        val dest = tmp.newFolder("out")
        extract(bos.toByteArray(), dest)
        assertEquals("echo", File(dest, "dir/run.sh").readText())
        assertTrue(File(dest, "dir/run.sh").canExecute())
        assertEquals("{}", File(dest, "zarvimo-runtime.json").readText())
    }

    @Test
    fun zipSlipRejected() {
        val bos = ByteArrayOutputStream()
        ZipArchiveOutputStream(bos).use { z ->
            z.putArchiveEntry(ZipArchiveEntry("../evil")); z.write(1); z.closeArchiveEntry()
        }
        try {
            extract(bos.toByteArray(), tmp.newFolder())
            fail()
        } catch (_: ArchiveException) {
        }
    }

    @Test
    fun rejectsUnknownAndZstdFormats() {
        for (bytes in listOf(ByteArray(2000) { 9 }, byteArrayOf(0x28, 0xB5.toByte(), 0x2F, 0xFD.toByte(), 0, 0, 0, 0))) {
            try {
                extract(bytes, tmp.newFolder())
                fail()
            } catch (_: ArchiveException) {
            }
        }
    }

    @Test
    fun cancellationAborts() {
        val b = TarBuilder(gzip = false)
        b.file("a", "A"); b.file("b", "B")
        try {
            extractor.extract(ByteArrayInputStream(b.finish()), tmp.newFolder(), checkCancelled = { throw java.util.concurrent.CancellationException("x") })
            fail()
        } catch (_: java.util.concurrent.CancellationException) {
        }
    }
}
