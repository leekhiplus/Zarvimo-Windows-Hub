package com.zarvimo.windowshub.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PeInspectorTest {
    private fun inspect(bytes: ByteArray, name: String = "a.exe") = PeInspector.inspect(BytesSource(bytes), name)

    @Test
    fun x64GuiExe() {
        val r = inspect(PeBuilder.build(machine = 0x8664, subsystem = 2))
        assertEquals(FileKind.PE_EXECUTABLE, r.kind)
        assertEquals(WinMachine.X64, r.machine)
        assertEquals(WinSubsystem.GUI, r.subsystem)
        assertFalse(r.isDotNet)
    }

    @Test
    fun x86ConsoleExe() {
        val r = inspect(PeBuilder.build(machine = 0x014C, subsystem = 3, pe32Plus = false))
        assertEquals(FileKind.PE_EXECUTABLE, r.kind)
        assertEquals(WinMachine.X86, r.machine)
        assertEquals(WinSubsystem.CONSOLE, r.subsystem)
    }

    @Test
    fun arm64Exe() {
        val r = inspect(PeBuilder.build(machine = 0xAA64))
        assertEquals(WinMachine.ARM64, r.machine)
    }

    @Test
    fun dllIsDetected() {
        val r = inspect(PeBuilder.build(dll = true), "lib.dll")
        assertEquals(FileKind.PE_DLL, r.kind)
    }

    @Test
    fun dotNetDetectedBothLayouts() {
        assertTrue(inspect(PeBuilder.build(clr = true)).isDotNet)
        assertTrue(inspect(PeBuilder.build(clr = true, pe32Plus = false, machine = 0x014C)).isDotNet)
        assertFalse(inspect(PeBuilder.build(clr = false)).isDotNet)
    }

    @Test
    fun msiDetectedByOleSignatureAndName() {
        val ole = ByteArray(512)
        val sig = intArrayOf(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1)
        for (i in sig.indices) ole[i] = sig[i].toByte()
        assertEquals(FileKind.MSI, inspect(ole, "setup.MSI").kind)
        assertEquals(FileKind.UNKNOWN, inspect(ole, "report.doc").kind)
    }

    @Test
    fun garbageIsUnknown() {
        assertEquals(FileKind.UNKNOWN, inspect(ByteArray(1000) { 7 }).kind)
        assertEquals(FileKind.UNKNOWN, inspect(ByteArray(3)).kind)
        assertEquals(FileKind.UNKNOWN, inspect(ByteArray(0)).kind)
    }

    @Test
    fun badPeOffsetIsUnknown() {
        val b = PeBuilder.build()
        b[0x3C] = 0xFF.toByte(); b[0x3D] = 0xFF.toByte(); b[0x3E] = 0xFF.toByte(); b[0x3F] = 0x7F
        assertEquals(FileKind.UNKNOWN, inspect(b).kind)
    }

    @Test
    fun missingPeSignatureIsUnknown() {
        val b = PeBuilder.build()
        b[0x80] = 'N'.code.toByte()
        assertEquals(FileKind.UNKNOWN, inspect(b).kind)
    }

    @Test
    fun truncatedHeaderDoesNotCrash() {
        val b = PeBuilder.build().copyOf(0x90)
        assertEquals(FileKind.UNKNOWN, inspect(b).kind)
    }
}
