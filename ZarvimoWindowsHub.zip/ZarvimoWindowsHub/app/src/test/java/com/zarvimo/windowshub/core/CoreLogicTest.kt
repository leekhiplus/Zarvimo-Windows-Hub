package com.zarvimo.windowshub.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class CoreLogicTest {
    @get:Rule
    val tmp = TemporaryFolder()

    // ---------- MiniJson ----------

    @Test
    fun jsonRoundTrip() {
        val src = mapOf(
            "s" to "he said \"hi\"\n\\ \u0001 é",
            "n" to 42L,
            "d" to 1.5,
            "b" to true,
            "z" to null,
            "l" to listOf(1L, "x", mapOf("k" to false)),
            "empty" to emptyMap<String, Any?>(),
        )
        for (pretty in listOf(false, true)) {
            val parsed = MiniJson.parseObject(MiniJson.stringify(src, pretty))
            assertEquals(src, parsed)
        }
    }

    @Test
    fun jsonRejectsMalformed() {
        for (bad in listOf("", "{", "{\"a\":}", "[1,]", "{\"a\":1} x", "\"unterminated", "{'a':1}", "01x")) {
            try {
                MiniJson.parse(bad)
                fail("should reject: $bad")
            } catch (_: JsonException) {
            }
        }
    }

    @Test
    fun jsonUnicodeEscape() {
        assertEquals("A\u00e9", MiniJson.parse("\"A\\u00e9\""))
    }

    // ---------- tokenizer / paths / env ----------

    @Test
    fun argTokenizer() {
        assertEquals(listOf("/S", "/D=C:\\Games dir"), ArgTokenizer.split("/S \"/D=C:\\Games dir\""))
        assertEquals(listOf("a b", "c"), ArgTokenizer.split("'a b'   c"))
        assertEquals(emptyList<String>(), ArgTokenizer.split("   "))
        assertEquals(listOf("C:\\x\\y.exe"), ArgTokenizer.split("C:\\x\\y.exe"))
        assertEquals(listOf(""), ArgTokenizer.split("\"\""))
        try {
            ArgTokenizer.split("\"oops")
            fail()
        } catch (_: IllegalArgumentException) {
        }
    }

    @Test
    fun windowsPath() {
        assertEquals("Z:\\data\\user\\a b.msi", WindowsPath.fromUnix("/data/user/a b.msi"))
    }

    @Test
    fun envText() {
        val env = EnvText.parse("# c\nFOO=bar baz\n\nA=1=2\n")
        assertEquals(mapOf("FOO" to "bar baz", "A" to "1=2"), env)
        for (bad in listOf("nokey", "1BAD=x", "=x", "A B=1")) {
            try {
                EnvText.parse(bad)
                fail("should reject: $bad")
            } catch (_: IllegalArgumentException) {
            }
        }
    }

    @Test
    fun byteFormat() {
        assertEquals("512 B", ByteFormat.human(512))
        assertEquals("1.0 KB", ByteFormat.human(1024))
        assertEquals("1.5 MB", ByteFormat.human(1536L * 1024))
    }

    // ---------- command template ----------

    @Test
    fun templateExpansion() {
        val t = mapOf("runtime" to "/r", "prefix" to "/p")
        assertEquals(
            listOf("/r/bin/box64", "/r/wine", "a", "b"),
            CommandTemplate.expand(listOf("{runtime}/bin/box64", "{runtime}/wine", "{wine-args}"), t, listOf("a", "b")),
        )
        try {
            CommandTemplate.expand(listOf("{nope}"), t, emptyList())
            fail()
        } catch (_: IllegalArgumentException) {
        }
        try {
            CommandTemplate.expand(listOf("x{wine-args}"), t, emptyList())
            fail()
        } catch (_: IllegalArgumentException) {
        }
    }

    // ---------- display ----------

    @Test
    fun displaySpec() {
        assertEquals(DisplaySpec("127.0.0.1", 0), DisplaySpec.parse(":0"))
        assertEquals(6003, DisplaySpec.parse("localhost:3.0")!!.port)
        assertEquals("10.0.0.5:1", DisplaySpec.parse("10.0.0.5:1")!!.envValue)
        assertNull(DisplaySpec.parse(""))
        assertNull(DisplaySpec.parse("unix:0"))
        assertNull(DisplaySpec.parse("/tmp/.X11-unix/X0"))
        assertNull(DisplaySpec.parse("host"))
        assertNull(DisplaySpec.parse("host:abc"))
        assertNull(DisplaySpec.parse("host:100"))
        assertNull(DisplaySpec.parse("bad host:0"))
    }

    @Test
    fun displayProbeDetectsListener() {
        java.net.ServerSocket(0).use { server ->
            val port = server.localPort
            // DisplaySpec ports are 6000 + n, so probe with a hand-built spec using a display number that matches.
            val spec = DisplaySpec("127.0.0.1", port - 6000)
            if (spec.display in 0..99) assertTrue(DisplayProbe.isReachable(spec))
        }
        assertTrue(!DisplayProbe.isReachable(DisplaySpec("127.0.0.1", 98), timeoutMs = 300))
    }

    // ---------- fs util ----------

    @Test
    fun entryNameNormalisation() {
        assertEquals("a/b", FsUtil.normalizeEntryName("./a//b/"))
        assertEquals("", FsUtil.normalizeEntryName("./"))
        assertNull(FsUtil.normalizeEntryName("../x"))
        assertNull(FsUtil.normalizeEntryName("a/../../x"))
        assertNull(FsUtil.normalizeEntryName("/etc/passwd"))
        assertNull(FsUtil.normalizeEntryName("a\\..\\b"))
    }

    @Test
    fun deleteTreeDoesNotFollowSymlinks() {
        val outside = tmp.newFolder("outside")
        val keep = File(outside, "keep.txt").apply { writeText("keep") }
        val tree = tmp.newFolder("tree")
        File(tree, "sub").mkdirs()
        File(tree, "sub/f").writeText("x")
        java.nio.file.Files.createSymbolicLink(File(tree, "link").toPath(), outside.toPath())
        FsUtil.deleteTreeNoFollow(tree)
        assertTrue(!tree.exists())
        assertTrue(keep.exists())
    }

    // ---------- manifest ----------

    private fun manifestJson(
        command: String = "[\"{runtime}/bin/wine\", \"{wine-args}\"]",
        extra: String = "",
    ) = """
        {
          "formatVersion": 1, "id": "wine-test", "name": "Wine Test", "version": "1", "wineVersion": "9.0",
          "hostAbi": "arm64-v8a", "windowsMachines": ["x64", "x86"], "translation": "box64",
          "command": $command,
          "env": {"WINEESYNC": "0", "LD_LIBRARY_PATH": "{runtime}/lib"},
          "executables": ["bin/wine"]$extra
        }
    """.trimIndent()

    @Test
    fun manifestParses() {
        val m = RuntimeManifestParser.parse(manifestJson())
        assertEquals("wine-test", m.id)
        assertEquals(setOf(WinMachine.X64, WinMachine.X86), m.windowsMachines)
        assertEquals("box64", m.translation)
        assertEquals(listOf("bin/wine"), m.executables)
    }

    @Test
    fun manifestRejectsBadInput() {
        val bad = listOf(
            manifestJson(command = "[\"/system/bin/sh\", \"{wine-args}\"]"),
            manifestJson(command = "[\"{runtime}/bin/wine\"]"),
            manifestJson(command = "[\"{runtime}/bin/wine\", \"{wine-args}\", \"{wine-args}\"]"),
            manifestJson(command = "[\"{runtime}/bin/{bogus}\", \"{wine-args}\"]"),
            manifestJson().replace("\"formatVersion\": 1", "\"formatVersion\": 2"),
            manifestJson().replace("arm64-v8a", "mips"),
            manifestJson().replace("[\"x64\", \"x86\"]", "[]"),
            manifestJson().replace("[\"x64\", \"x86\"]", "[\"ppc\"]"),
            manifestJson().replace("wine-test", "Bad Id!"),
            manifestJson().replace("\"bin/wine\"", "\"../evil\""),
            "not json",
        )
        for (b in bad) {
            try {
                RuntimeManifestParser.parse(b)
                fail("should reject: $b")
            } catch (_: ManifestException) {
            }
        }
    }

    // ---------- planner ----------

    private fun runtime(abi: String = "arm64-v8a"): Pair<RuntimeManifest, File> {
        val dir = tmp.newFolder()
        File(dir, "bin").mkdirs()
        val wine = File(dir, "bin/wine").apply { writeText("#!/bin/sh\n"); setExecutable(true) }
        assertTrue(wine.canExecute())
        val m = RuntimeManifestParser.parse(manifestJson().replace("arm64-v8a", abi))
        return m to dir
    }

    private fun ctx(m: RuntimeManifest, dir: File, display: String = "", reachable: Boolean = false, abis: List<String> = listOf("arm64-v8a", "armeabi-v7a")): PlanContext {
        val prefix = tmp.newFolder()
        return PlanContext(m, dir, prefix, PrefixSettings(display = display, extraEnv = mapOf("X" to "1")), tmp.newFolder(), tmp.newFolder(), abis, reachable)
    }

    private fun exe(machine: Int, subsystem: Int, dotnet: Boolean = false): WineJob.RunProgram {
        val bytes = PeBuilder.build(machine = machine, subsystem = subsystem, clr = dotnet)
        val f = tmp.newFile().also { it.writeBytes(bytes) }
        return WineJob.RunProgram(f, PeInspector.inspect(f), listOf("--flag"))
    }

    @Test
    fun plannerReadyForConsoleProgramWithoutDisplay() {
        val (m, dir) = runtime()
        val c = ctx(m, dir)
        val r = LaunchPlanner.plan(exe(0x8664, 3), c)
        assertTrue(r.toString(), r is PlanResult.Ready)
        val plan = (r as PlanResult.Ready).plan
        assertEquals(File(dir, "bin/wine").absolutePath, plan.command[0])
        assertEquals("--flag", plan.command.last())
        assertEquals(c.prefixDir!!.absolutePath, plan.environment["WINEPREFIX"])
        assertEquals("1", plan.environment["X"])
        assertEquals(File(dir, "lib").absolutePath, plan.environment["LD_LIBRARY_PATH"])
        assertNull(plan.environment["DISPLAY"])
    }

    @Test
    fun plannerBlocksGuiWithoutDisplayThenAllowsWithReachableDisplay() {
        val (m, dir) = runtime()
        val job = exe(0x8664, 2)
        val blocked = LaunchPlanner.plan(job, ctx(m, dir))
        assertTrue(blocked is PlanResult.Blocked)
        val unreachable = LaunchPlanner.plan(job, ctx(m, dir, display = "127.0.0.1:0", reachable = false))
        assertTrue(unreachable is PlanResult.Blocked)
        val ok = LaunchPlanner.plan(job, ctx(m, dir, display = ":0", reachable = true))
        assertTrue(ok is PlanResult.Ready)
        assertEquals("127.0.0.1:0", (ok as PlanResult.Ready).plan.environment["DISPLAY"])
    }

    @Test
    fun plannerBlocksArchitectureMismatches() {
        val (m, dir) = runtime()
        // ARM64 Windows program on a runtime that only runs x86/x64.
        assertTrue(LaunchPlanner.plan(exe(0xAA64, 3), ctx(m, dir)) is PlanResult.Blocked)
        // Runtime built for x86_64 on an arm64-only device.
        val (m2, dir2) = runtime(abi = "x86_64")
        assertTrue(LaunchPlanner.plan(exe(0x8664, 3), ctx(m2, dir2)) is PlanResult.Blocked)
    }

    @Test
    fun plannerBlocksNonExecutablesAndMissingRuntimeFiles() {
        val (m, dir) = runtime()
        val junk = tmp.newFile().also { it.writeBytes(ByteArray(300) { 1 }) }
        assertTrue(LaunchPlanner.plan(WineJob.RunProgram(junk, PeInspector.inspect(junk), emptyList()), ctx(m, dir)) is PlanResult.Blocked)
        File(dir, "bin/wine").delete()
        assertTrue(LaunchPlanner.plan(WineJob.VersionCheck, ctx(m, dir)) is PlanResult.Blocked)
    }

    @Test
    fun plannerBuildsMsiAndInitCommands() {
        val (m, dir) = runtime()
        val msi = File(tmp.newFolder(), "setup.msi").apply { writeBytes(ByteArray(10)) }
        val r = LaunchPlanner.plan(WineJob.InstallMsi(msi, quiet = true, extraArgs = listOf("A=1")), ctx(m, dir))
        assertTrue(r.toString(), r is PlanResult.Ready)
        val cmd = (r as PlanResult.Ready).plan.command
        assertEquals(listOf("msiexec", "/i", WindowsPath.fromUnix(msi.absolutePath), "/qn", "A=1"), cmd.drop(1))
        // Non-quiet MSI needs a display.
        assertTrue(LaunchPlanner.plan(WineJob.InstallMsi(msi, quiet = false, extraArgs = emptyList()), ctx(m, dir)) is PlanResult.Blocked)

        val init = LaunchPlanner.plan(WineJob.InitPrefix, ctx(m, dir)) as PlanResult.Ready
        assertEquals(listOf("wineboot", "--init"), init.plan.command.drop(1))
        assertEquals("mscoree,mshtml=", init.plan.environment["WINEDLLOVERRIDES"])
    }

    @Test
    fun plannerWarnsAboutDotNet() {
        val (m, dir) = runtime()
        val r = LaunchPlanner.plan(exe(0x8664, 3, dotnet = true), ctx(m, dir)) as PlanResult.Ready
        assertTrue(r.warnings.any { it.contains(".NET") })
        assertNotNull(r.plan.stopCommand ?: "none")
    }
}
