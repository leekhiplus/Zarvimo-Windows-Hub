package com.zarvimo.windowshub.core

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.nio.file.attribute.PosixFilePermission

/** Plain-JVM implementation of the platform file operations used by the extractor. */
object JvmFileOps : FileOps {
    override fun symlink(target: String, link: File) {
        Files.createSymbolicLink(link.toPath(), java.nio.file.Paths.get(target))
    }

    override fun chmod(file: File, mode: Int) {
        val perms = HashSet<PosixFilePermission>()
        val all = arrayOf(
            PosixFilePermission.OTHERS_EXECUTE, PosixFilePermission.OTHERS_WRITE, PosixFilePermission.OTHERS_READ,
            PosixFilePermission.GROUP_EXECUTE, PosixFilePermission.GROUP_WRITE, PosixFilePermission.GROUP_READ,
            PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_READ,
        )
        for (i in all.indices) if ((mode shr i) and 1 == 1) perms.add(all[i])
        Files.setPosixFilePermissions(file.toPath(), perms)
    }
}

/** Builds a minimal but structurally valid PE image header for tests. */
object PeBuilder {
    fun build(
        machine: Int = 0x8664,
        subsystem: Int = 2,
        dll: Boolean = false,
        pe32Plus: Boolean = true,
        clr: Boolean = false,
    ): ByteArray {
        val buf = ByteBuffer.allocate(0x400).order(ByteOrder.LITTLE_ENDIAN)
        buf.put(0, 'M'.code.toByte()); buf.put(1, 'Z'.code.toByte())
        buf.putInt(0x3C, 0x80)
        val pe = 0x80
        buf.put(pe, 'P'.code.toByte()); buf.put(pe + 1, 'E'.code.toByte())
        buf.putShort(pe + 4, machine.toShort())
        buf.putShort(pe + 6, 1) // sections
        val sizeOpt = if (pe32Plus) 240 else 224
        buf.putShort(pe + 20, sizeOpt.toShort())
        buf.putShort(pe + 22, (0x0002 or (if (dll) 0x2000 else 0)).toShort())
        val opt = pe + 24
        buf.putShort(opt, (if (pe32Plus) 0x20B else 0x10B).toShort())
        buf.putShort(opt + 68, subsystem.toShort())
        val numRvaOff = opt + if (pe32Plus) 108 else 92
        val dirs = opt + if (pe32Plus) 112 else 96
        buf.putInt(numRvaOff, 16)
        if (clr) {
            buf.putInt(dirs + 14 * 8, 0x2000)
            buf.putInt(dirs + 14 * 8 + 4, 0x48)
        }
        return buf.array()
    }
}
