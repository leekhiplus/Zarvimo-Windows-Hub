package com.zarvimo.windowshub.runtime

import com.zarvimo.windowshub.core.LaunchPlan
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** Uses real child processes (/bin/sh); the manager must report what really happened. */
class SessionManagerTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var manager: SessionManager
    private lateinit var work: File

    @Before
    fun setUp() {
        work = tmp.newFolder("work")
        manager = SessionManager(scope, tmp.newFolder("logs"))
    }

    @After
    fun tearDown() {
        scope.cancel()
    }

    private fun plan(vararg cmd: String, env: Map<String, String> = emptyMap()) =
        LaunchPlan("test", cmd.toList(), env + mapOf("PATH" to "/usr/bin:/bin"), work, null)

    private fun awaitDone(id: String, timeoutMs: Long = 10_000): SessionInfo {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val s = manager.sessions.value.firstOrNull { it.id == id }
            if (s != null && s.status != SessionStatus.RUNNING) return s
            Thread.sleep(20)
        }
        throw AssertionError("session did not finish")
    }

    @Test
    fun capturesOutputAndExitCode() {
        val id = manager.start(plan("/bin/sh", "-c", "echo hello-out; echo hello-err 1>&2; echo \"v=\$ZV\"; exit 3", env = mapOf("ZV" to "42")), null)
        val done = awaitDone(id)
        assertEquals(SessionStatus.EXITED, done.status)
        assertEquals(3, done.exitCode)
        val log = manager.readLogTail(id)
        assertTrue(log, log.contains("hello-out"))
        assertTrue(log, log.contains("hello-err"))
        assertTrue(log, log.contains("v=42"))
        assertTrue(log, log.contains("exit code 3"))
        assertEquals(0, manager.activeCount.value)
    }

    @Test
    fun environmentIsExactlyThePlanned() {
        val id = manager.start(plan("/bin/sh", "-c", "echo \"home=[\$HOME]\"", env = mapOf("ONLY" to "1")), null)
        awaitDone(id)
        assertTrue(manager.readLogTail(id), manager.readLogTail(id).contains("home=[]"))
    }

    @Test
    fun missingExecutableIsReportedAsFailedToStart() {
        val id = manager.start(plan("/definitely/not/here"), null)
        val done = awaitDone(id)
        assertEquals(SessionStatus.FAILED_TO_START, done.status)
        assertNotNull(done.detail)
        assertTrue(manager.readLogTail(id).contains("Could not start"))
    }

    @Test
    fun stopTerminatesRunningProcess() {
        val id = manager.start(plan("/bin/sh", "-c", "sleep 30"), null)
        // wait until running
        Thread.sleep(300)
        assertEquals(SessionStatus.RUNNING, manager.sessions.value.first { it.id == id }.status)
        assertEquals(1, manager.activeCount.value)
        manager.stop(id)
        val done = awaitDone(id)
        assertEquals(SessionStatus.STOPPED, done.status)
    }

    @Test
    fun finishCallbackRuns() {
        var seen: SessionInfo? = null
        val id = manager.start(plan("/bin/sh", "-c", "exit 0"), "p1") { seen = it }
        awaitDone(id)
        Thread.sleep(100)
        assertEquals("p1", seen?.prefixId)
        assertEquals(0, seen?.exitCode)
    }
}
