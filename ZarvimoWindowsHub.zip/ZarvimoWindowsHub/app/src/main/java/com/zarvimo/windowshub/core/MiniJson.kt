package com.zarvimo.windowshub.core

/** Thrown for any malformed JSON input. */
class JsonException(message: String) : Exception(message)

/**
 * Small, dependency-free JSON reader/writer.
 *
 * Parsed values are: Map<String, Any?>, List<Any?>, String, Long, Double, Boolean or null.
 * Kept in pure Kotlin (no org.json) so the logic that depends on it can be unit-tested on a plain JVM.
 */
object MiniJson {
    private const val MAX_DEPTH = 64

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.readValue(0)
        p.skipWs()
        if (!p.atEnd()) throw JsonException("Unexpected trailing data at position ${p.pos}")
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun parseObject(text: String): Map<String, Any?> {
        val v = parse(text)
        if (v !is Map<*, *>) throw JsonException("Top-level JSON value must be an object")
        return v as Map<String, Any?>
    }

    fun stringify(value: Any?, pretty: Boolean = false): String {
        val sb = StringBuilder()
        write(sb, value, pretty, 0)
        return sb.toString()
    }

    private fun write(sb: StringBuilder, v: Any?, pretty: Boolean, indent: Int) {
        when (v) {
            null -> sb.append("null")
            is String -> writeString(sb, v)
            is Boolean -> sb.append(if (v) "true" else "false")
            is Int -> sb.append(v)
            is Long -> sb.append(v)
            is Double -> {
                if (v.isNaN() || v.isInfinite()) throw JsonException("Cannot encode NaN/Infinity")
                sb.append(v)
            }
            is Map<*, *> -> {
                if (v.isEmpty()) {
                    sb.append("{}")
                    return
                }
                sb.append('{')
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(',')
                    first = false
                    if (pretty) newline(sb, indent + 1)
                    writeString(sb, k as? String ?: throw JsonException("Map keys must be strings"))
                    sb.append(if (pretty) ": " else ":")
                    write(sb, value, pretty, indent + 1)
                }
                if (pretty) newline(sb, indent)
                sb.append('}')
            }
            is List<*> -> {
                if (v.isEmpty()) {
                    sb.append("[]")
                    return
                }
                sb.append('[')
                var first = true
                for (item in v) {
                    if (!first) sb.append(',')
                    first = false
                    if (pretty) newline(sb, indent + 1)
                    write(sb, item, pretty, indent + 1)
                }
                if (pretty) newline(sb, indent)
                sb.append(']')
            }
            else -> throw JsonException("Unsupported JSON value type: ${v::class.java.name}")
        }
    }

    private fun newline(sb: StringBuilder, indent: Int) {
        sb.append('\n')
        repeat(indent) { sb.append("  ") }
    }

    private fun writeString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') {
                    sb.append("\\u").append(String.format("%04x", c.code))
                } else {
                    sb.append(c)
                }
            }
        }
        sb.append('"')
    }

    private class Parser(private val s: String) {
        var pos = 0

        fun atEnd() = pos >= s.length

        fun skipWs() {
            while (pos < s.length && (s[pos] == ' ' || s[pos] == '\n' || s[pos] == '\r' || s[pos] == '\t')) pos++
        }

        fun readValue(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw JsonException("JSON nested too deeply")
            if (atEnd()) throw JsonException("Unexpected end of JSON")
            return when (val c = s[pos]) {
                '{' -> readObject(depth)
                '[' -> readArray(depth)
                '"' -> readString()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (c == '-' || c in '0'..'9') readNumber() else throw JsonException("Unexpected character '$c' at position $pos")
            }
        }

        private fun literal(word: String, value: Any?): Any? {
            if (!s.startsWith(word, pos)) throw JsonException("Invalid literal at position $pos")
            pos += word.length
            return value
        }

        private fun readObject(depth: Int): Map<String, Any?> {
            pos++ // {
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (pos < s.length && s[pos] == '}') {
                pos++
                return out
            }
            while (true) {
                skipWs()
                if (atEnd() || s[pos] != '"') throw JsonException("Expected string key at position $pos")
                val key = readString()
                skipWs()
                if (atEnd() || s[pos] != ':') throw JsonException("Expected ':' at position $pos")
                pos++
                skipWs()
                out[key] = readValue(depth + 1)
                skipWs()
                if (atEnd()) throw JsonException("Unterminated object")
                when (s[pos]) {
                    ',' -> pos++
                    '}' -> {
                        pos++
                        return out
                    }
                    else -> throw JsonException("Expected ',' or '}' at position $pos")
                }
            }
        }

        private fun readArray(depth: Int): List<Any?> {
            pos++ // [
            val out = ArrayList<Any?>()
            skipWs()
            if (pos < s.length && s[pos] == ']') {
                pos++
                return out
            }
            while (true) {
                skipWs()
                out.add(readValue(depth + 1))
                skipWs()
                if (atEnd()) throw JsonException("Unterminated array")
                when (s[pos]) {
                    ',' -> pos++
                    ']' -> {
                        pos++
                        return out
                    }
                    else -> throw JsonException("Expected ',' or ']' at position $pos")
                }
            }
        }

        private fun readString(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonException("Unterminated string")
                val c = s[pos++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (atEnd()) throw JsonException("Unterminated escape")
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) throw JsonException("Bad unicode escape")
                                val hex = s.substring(pos, pos + 4)
                                val code = hex.toIntOrNull(16) ?: throw JsonException("Bad unicode escape '$hex'")
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> throw JsonException("Bad escape '\\$e'")
                        }
                    }
                    c < ' ' -> throw JsonException("Control character in string at position ${pos - 1}")
                    else -> sb.append(c)
                }
            }
        }

        private fun readNumber(): Any {
            val start = pos
            if (s[pos] == '-') pos++
            while (pos < s.length && s[pos] in '0'..'9') pos++
            var isFloat = false
            if (pos < s.length && s[pos] == '.') {
                isFloat = true
                pos++
                while (pos < s.length && s[pos] in '0'..'9') pos++
            }
            if (pos < s.length && (s[pos] == 'e' || s[pos] == 'E')) {
                isFloat = true
                pos++
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) pos++
                while (pos < s.length && s[pos] in '0'..'9') pos++
            }
            val text = s.substring(start, pos)
            if (text == "-" || text.isEmpty()) throw JsonException("Invalid number at position $start")
            return if (isFloat) {
                text.toDoubleOrNull() ?: throw JsonException("Invalid number '$text'")
            } else {
                text.toLongOrNull() ?: (text.toDoubleOrNull() ?: throw JsonException("Invalid number '$text'"))
            }
        }
    }
}

// ---- Typed accessors used by the stores / manifest parser ----

fun Map<String, Any?>.optString(key: String): String? = this[key] as? String

fun Map<String, Any?>.optLong(key: String, default: Long = 0L): Long = when (val v = this[key]) {
    is Long -> v
    is Double -> v.toLong()
    else -> default
}

fun Map<String, Any?>.optBoolean(key: String, default: Boolean = false): Boolean = (this[key] as? Boolean) ?: default

@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.optMap(key: String): Map<String, Any?>? = this[key] as? Map<String, Any?>

fun Map<String, Any?>.optList(key: String): List<Any?>? = this[key] as? List<Any?>
