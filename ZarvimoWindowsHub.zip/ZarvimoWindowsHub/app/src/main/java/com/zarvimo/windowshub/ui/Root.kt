package com.zarvimo.windowshub.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.Tab

private fun Tab.icon(): ImageVector = when (this) {
    Tab.LIBRARY -> Icons.Default.Home
    Tab.ENVIRONMENTS -> Icons.Default.Settings
    Tab.RUNTIMES -> Icons.Default.Build
    Tab.SESSIONS -> Icons.Default.PlayArrow
    Tab.ABOUT -> Icons.Default.Info
}

@Composable
fun ZarvimoRoot(vm: MainViewModel) {
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val tab by vm.tab.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val scan by vm.scan.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    Surface(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { vm.selectTab(t) },
                            icon = { Icon(t.icon(), contentDescription = null) },
                            label = { Text(t.label, maxLines = 1) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                if (!loaded) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else {
                    when (tab) {
                        Tab.LIBRARY -> LibraryScreen(vm)
                        Tab.ENVIRONMENTS -> EnvironmentsScreen(vm)
                        Tab.RUNTIMES -> RuntimesScreen(vm)
                        Tab.SESSIONS -> SessionsScreen(vm)
                        Tab.ABOUT -> StatusScreen(vm)
                    }
                }
            }
        }
    }

    progress?.let { ProgressDialog(it, onCancel = { vm.cancelOperation() }) }
    notice?.let { NoticeDialog(it, onDismiss = { vm.dismissNotice() }) }
    scan?.let { ScanDialog(vm, it.prefixId, it.files, onDismiss = { vm.dismissScan() }) }
}
