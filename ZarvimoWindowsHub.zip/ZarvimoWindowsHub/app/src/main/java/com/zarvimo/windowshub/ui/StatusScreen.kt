package com.zarvimo.windowshub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.core.ByteFormat
import com.zarvimo.windowshub.data.EnvironmentReport
import com.zarvimo.windowshub.data.ExecCheck

private val IMPLEMENTED = listOf(
    "Import .exe / .msi files into private storage; file type, CPU architecture, subsystem and .NET flag are read from the real PE / OLE headers.",
    "Install a user-supplied Wine runtime package (.tar.xz, .tar.gz, .tar.bz2, .tar, .zip) with path-traversal and symlink-escape protection, manifest validation and executable checks.",
    "Create isolated Wine prefixes (\"environments\"), initialize them with wineboot, and record success only when Wine really wrote its registry.",
    "Start real child processes for programs, MSI installs (msiexec), winecfg, regedit and runtime version checks, with live output, exit codes, stop, and shareable logs.",
    "Refuse launches that cannot work, and say why: CPU mismatch between program, runtime and device, missing X11 display, missing runtime files.",
    "Keep processes alive in the background through a foreground service while any are running.",
)

private val NOT_INCLUDED = listOf(
    "No Wine, Box64, FEX or other binaries are bundled. Without an installed runtime package nothing can be launched.",
    "No X server and no screen output. Graphical programs need a separate Android X server app reachable over TCP; Zarvimo only points Wine at it.",
    "No audio routing, controller mapping, GPU / DirectX / Vulkan translation or performance tuning beyond what your runtime package provides.",
    "No installation of Wine Mono, Gecko, Visual C++ runtimes or other Windows components; install them yourself inside an environment.",
    "Drivers, kernel-level anti-cheat, DRM-protected software and 16-bit programs are not supported.",
    "Not distributed through Google Play; it targets API 28 on purpose so Android lets it execute runtime binaries (see README).",
)

private val CANNOT_KNOW = listOf(
    "Whether a particular Windows program works. That depends on the program, your runtime and your device. A started process is not the same as a working program: read the session log.",
)

@Composable
fun StatusScreen(vm: MainViewModel) {
    val report by vm.envReport.collectAsStateWithLifecycle()
    val checking by vm.envChecking.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Status", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Text(
            "Zarvimo Windows Hub is a front end for a Wine compatibility layer that you provide. It does not emulate Windows itself, " +
                "and it cannot promise that any given Windows application runs on Android.",
            style = MaterialTheme.typography.bodyMedium,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("This device", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                val r = report
                if (r == null) {
                    Text(if (checking) "Checking…" else "Not checked yet.")
                } else {
                    DeviceFacts(r)
                }
                Button(enabled = !checking, onClick = { vm.refreshEnvironment() }) { Text(if (checking) "Checking…" else "Run check again") }
            }
        }

        Section("Implemented in this build", IMPLEMENTED)
        Section("Not included / not supported", NOT_INCLUDED)
        Section("Cannot be known in advance", CANNOT_KNOW)
    }
}

@Composable
private fun DeviceFacts(r: EnvironmentReport) {
    KeyValue("Android", "${r.androidRelease} (API ${r.sdkInt})")
    KeyValue("CPU ABIs", r.supportedAbis.joinToString())
    KeyValue("Memory", ByteFormat.human(r.totalRamBytes) + " total")
    KeyValue("Free storage", ByteFormat.human(r.freeBytes))
    KeyValue("App target API", r.appTargetSdk.toString())
    val (label, text, warn) = when (val e = r.exec) {
        ExecCheck.Allowed -> Triple("Passed", "This device allows running binaries from app storage (tested by actually running one).", false)
        is ExecCheck.Blocked -> Triple("Blocked", e.detail, true)
        is ExecCheck.Unavailable -> Triple("Inconclusive", e.detail, true)
    }
    KeyValue("Run-from-storage test", label)
    Tag(label, warn = warn)
    Text(text, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun Section(title: String, lines: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        lines.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
    }
}
