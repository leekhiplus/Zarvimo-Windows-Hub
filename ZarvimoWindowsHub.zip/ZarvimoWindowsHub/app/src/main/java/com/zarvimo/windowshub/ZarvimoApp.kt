package com.zarvimo.windowshub

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.zarvimo.windowshub.data.AppPaths
import com.zarvimo.windowshub.data.EnvironmentChecker
import com.zarvimo.windowshub.data.LibraryRepository
import com.zarvimo.windowshub.data.PrefixRepository
import com.zarvimo.windowshub.data.RuntimeRepository
import com.zarvimo.windowshub.runtime.SessionManager
import com.zarvimo.windowshub.runtime.SessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Plain manual dependency container; there is exactly one per process. */
class AppContainer(app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val paths = AppPaths(app)
    val deviceAbis: List<String> = Build.SUPPORTED_ABIS.toList()
    val library = LibraryRepository(paths)
    val runtimes = RuntimeRepository(paths, deviceAbis)
    val prefixes = PrefixRepository(paths)
    val sessions = SessionManager(scope, paths.logs)
    val environment = EnvironmentChecker(app, paths)

    @Volatile
    private var loaded = false

    /** Blocking; call off the main thread. Loads from disk once per process. */
    @Synchronized
    fun loadAll() {
        if (loaded) return
        loaded = true
        paths.ensure()
        library.load()
        runtimes.load()
        prefixes.load()
        sessions.pruneLogs()
    }
}

class ZarvimoApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        // Keep Windows processes alive in the background while any are running.
        container.scope.launch {
            container.sessions.activeCount.collect { count ->
                if (count > 0) {
                    try {
                        ContextCompat.startForegroundService(this@ZarvimoApp, Intent(this@ZarvimoApp, SessionService::class.java))
                    } catch (_: Exception) {
                        // Starting a service can be refused when the app is in the background; processes keep running regardless.
                    }
                }
            }
        }
    }
}
