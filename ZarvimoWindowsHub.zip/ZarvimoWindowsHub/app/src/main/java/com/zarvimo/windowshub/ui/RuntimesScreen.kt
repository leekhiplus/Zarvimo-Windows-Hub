package com.zarvimo.windowshub.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.core.ByteFormat
import com.zarvimo.windowshub.data.RuntimeEntry

@Composable
fun RuntimesScreen(vm: MainViewModel) {
    val runtimes by vm.runtimes.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.installRuntime(uri) }
    var removeTarget by remember { mutableStateOf<RuntimeEntry?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Runtimes",
            "A runtime is a Wine build (optionally with a CPU translator such as Box64) packaged for Zarvimo. " +
                "This app does not include one; you supply a package that follows docs/RUNTIME_FORMAT.md.",
        ) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Install runtime package") }
        }
        if (runtimes.isEmpty()) {
            InfoCard(
                "No runtime installed",
                "Until a runtime is installed, nothing can be launched. Supported package formats: .tar.xz, .tar.gz, .tar.bz2, .tar, .zip. " +
                    "The package must contain zarvimo-runtime.json at its top level, built for this device's CPU (${vm.deviceAbis.joinToString()}).",
            )
        } else {
            LazyColumn(contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(runtimes, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            val m = r.manifest
                            if (m == null) {
                                Text(r.id, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Tag("Unusable", warn = true)
                                Text(r.problem ?: "Unknown problem.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            } else {
                                Text("${m.name} ${m.version}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Tag("Wine ${m.wineVersion}")
                                    Tag(m.hostAbi, warn = m.hostAbi !in vm.deviceAbis)
                                    m.translation?.let { Tag("translation: $it") }
                                }
                                KeyValue("Runs Windows", m.windowsMachines.joinToString { it.label })
                                KeyValue("Size on disk", ByteFormat.human(r.sizeBytes))
                                if (m.hostAbi !in vm.deviceAbis) {
                                    Text(
                                        "Built for ${m.hostAbi}; this device supports ${vm.deviceAbis.joinToString()}. It cannot run here.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                                m.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                                m.licenseNotes?.let {
                                    Text("License notes: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (m != null) {
                                    OutlinedButton(onClick = { vm.checkRuntime(r.id) }) { Text("Run version check") }
                                }
                                TextButton(onClick = { removeTarget = r }) { Text("Remove") }
                            }
                        }
                    }
                }
            }
        }
    }

    removeTarget?.let { r ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text("Remove runtime?") },
            text = { Text("Deletes the runtime files. Environments that use it must be deleted first.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeRuntime(r.id)
                    removeTarget = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { removeTarget = null }) { Text("Cancel") } },
        )
    }
}
