package com.zarvimo.windowshub.data

import com.zarvimo.windowshub.core.FileKind
import com.zarvimo.windowshub.core.FsUtil
import com.zarvimo.windowshub.core.PeInspector
import com.zarvimo.windowshub.core.WinMachine
import com.zarvimo.windowshub.core.WinSubsystem
import com.zarvimo.windowshub.core.optBoolean
import com.zarvimo.windowshub.core.optList
import com.zarvimo.windowshub.core.optLong
import com.zarvimo.windowshub.core.optString
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

enum class ItemSource { IMPORTED, PREFIX }

data class LibraryItem(
    val id: String,
    val displayName: String,
    val fileName: String,
    val source: ItemSource,
    /** Absolute path of the file (an imported copy, or a program inside an environment). */
    val path: String,
    val prefixId: String?,
    val sizeBytes: Long,
    val sha256: String,
    val kind: FileKind,
    val machine: WinMachine?,
    val subsystem: WinSubsystem,
    val isDotNet: Boolean,
    val notes: List<String>,
    val addedAt: Long,
) {
    fun toJson(): Map<String, Any?> = linkedMapOf(
        "id" to id,
        "displayName" to displayName,
        "fileName" to fileName,
        "source" to source.name,
        "path" to path,
        "prefixId" to prefixId,
        "sizeBytes" to sizeBytes,
        "sha256" to sha256,
        "kind" to kind.name,
        "machine" to machine?.name,
        "subsystem" to subsystem.name,
        "isDotNet" to isDotNet,
        "notes" to notes,
        "addedAt" to addedAt,
    )

    companion object {
        fun fromJson(m: Map<String, Any?>): LibraryItem? {
            val id = m.optString("id") ?: return null
            val path = m.optString("path") ?: return null
            return LibraryItem(
                id = id,
                displayName = m.optString("displayName") ?: File(path).name,
                fileName = m.optString("fileName") ?: File(path).name,
                source = enumOr(m.optString("source"), ItemSource.IMPORTED),
                path = path,
                prefixId = m.optString("prefixId"),
                sizeBytes = m.optLong("sizeBytes"),
                sha256 = m.optString("sha256") ?: "",
                kind = enumOr(m.optString("kind"), FileKind.UNKNOWN),
                machine = m.optString("machine")?.let { name -> WinMachine.entries.firstOrNull { it.name == name } },
                subsystem = enumOr(m.optString("subsystem"), WinSubsystem.NONE),
                isDotNet = m.optBoolean("isDotNet"),
                notes = m.optList("notes")?.filterIsInstance<String>() ?: emptyList(),
                addedAt = m.optLong("addedAt"),
            )
        }

        private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
            enumValues<E>().firstOrNull { it.name == name } ?: default
    }
}

/** Raised when a file is refused with a reason the user should see. */
class ImportRejectedException(message: String) : Exception(message)

class LibraryRepository(private val paths: AppPaths) {
    private val indexFile = File(paths.library, "index.json")
    private val lock = Any()
    private val state = MutableStateFlow<List<LibraryItem>>(emptyList())
    val items: StateFlow<List<LibraryItem>> = state.asStateFlow()

    fun load() = synchronized(lock) {
        val root = JsonFile.readObject(indexFile)
        val loaded = (root?.optList("items") ?: emptyList())
            .mapNotNull { (it as? Map<*, *>)?.let { m -> @Suppress("UNCHECKED_CAST") LibraryItem.fromJson(m as Map<String, Any?>) } }
        // Drop entries whose file no longer exists.
        val present = loaded.filter { File(it.path).isFile }
        state.value = present
        if (present.size != loaded.size) persist()
    }

    fun find(id: String): LibraryItem? = state.value.firstOrNull { it.id == id }

    /**
     * Copies a Windows .exe/.msi into private storage, hashes it and reads its headers.
     * Files that are not a PE executable or MSI are refused (and nothing is kept).
     */
    fun importStream(
        displayName: String,
        expectedSize: Long,
        open: () -> InputStream,
        progress: (Long) -> Unit,
        checkCancelled: () -> Unit,
    ): LibraryItem {
        if (expectedSize > 0 && paths.library.usableSpace < expectedSize + 32L * 1024 * 1024) {
            throw ImportRejectedException("Not enough free storage to import this file.")
        }
        val id = newId()
        val dir = File(paths.library, id)
        if (!dir.mkdirs()) throw IOException("Could not create storage folder.")
        val safeName = sanitizeFileName(displayName)
        val target = File(dir, safeName)
        try {
            val md = MessageDigest.getInstance("SHA-256")
            var total = 0L
            open().use { input ->
                FileOutputStream(target).use { out ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        checkCancelled()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        total += n
                        progress(total)
                    }
                }
            }
            val inspection = PeInspector.inspect(target)
            when (inspection.kind) {
                FileKind.PE_EXECUTABLE, FileKind.MSI -> {}
                FileKind.PE_DLL -> throw ImportRejectedException("\"$displayName\" is a DLL library, not a program or installer.")
                FileKind.UNKNOWN -> throw ImportRejectedException(
                    "\"$displayName\" is not a Windows .exe or .msi. " + (inspection.notes.firstOrNull() ?: ""),
                )
            }
            val sha = md.digest().joinToString("") { "%02x".format(it) }
            val item = LibraryItem(
                id = id,
                displayName = displayName.substringBeforeLast('.', displayName),
                fileName = safeName,
                source = ItemSource.IMPORTED,
                path = target.absolutePath,
                prefixId = null,
                sizeBytes = total,
                sha256 = sha,
                kind = inspection.kind,
                machine = inspection.machine,
                subsystem = inspection.subsystem,
                isDotNet = inspection.isDotNet,
                notes = inspection.notes,
                addedAt = System.currentTimeMillis(),
            )
            synchronized(lock) {
                val dup = state.value.firstOrNull { it.sha256 == sha && it.sizeBytes == total && it.source == ItemSource.IMPORTED }
                if (dup != null) throw ImportRejectedException("Already in the library as \"${dup.displayName}\".")
                state.value = state.value + item
                persist()
            }
            return item
        } catch (t: Throwable) {
            FsUtil.deleteTreeNoFollow(dir)
            throw t
        }
    }

    /** Adds a program that already exists inside an environment (for example after running an installer). */
    fun addPrefixProgram(prefixId: String, file: File): LibraryItem {
        if (!file.isFile) throw ImportRejectedException("File not found.")
        val inspection = PeInspector.inspect(file)
        if (inspection.kind != FileKind.PE_EXECUTABLE) throw ImportRejectedException("${file.name} is not a Windows executable.")
        synchronized(lock) {
            if (state.value.any { it.path == file.absolutePath }) throw ImportRejectedException("Already in the library.")
        }
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(128 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        val item = LibraryItem(
            id = newId(),
            displayName = file.name.substringBeforeLast('.'),
            fileName = file.name,
            source = ItemSource.PREFIX,
            path = file.absolutePath,
            prefixId = prefixId,
            sizeBytes = file.length(),
            sha256 = md.digest().joinToString("") { "%02x".format(it) },
            kind = inspection.kind,
            machine = inspection.machine,
            subsystem = inspection.subsystem,
            isDotNet = inspection.isDotNet,
            notes = inspection.notes,
            addedAt = System.currentTimeMillis(),
        )
        synchronized(lock) {
            state.value = state.value + item
            persist()
        }
        return item
    }

    fun rename(id: String, newName: String) = synchronized(lock) {
        val name = newName.trim().take(80)
        if (name.isEmpty()) return@synchronized
        state.value = state.value.map { if (it.id == id) it.copy(displayName = name) else it }
        persist()
    }

    /** Removes the entry. For imported files the stored copy is deleted too; files inside environments are left alone. */
    fun remove(id: String) {
        val item: LibraryItem
        synchronized(lock) {
            item = state.value.firstOrNull { it.id == id } ?: return
            state.value = state.value.filter { it.id != id }
            persist()
        }
        if (item.source == ItemSource.IMPORTED) FsUtil.deleteTreeNoFollow(File(paths.library, item.id))
    }

    fun removeForPrefix(prefixId: String) = synchronized(lock) {
        state.value = state.value.filter { !(it.source == ItemSource.PREFIX && it.prefixId == prefixId) }
        persist()
    }

    private fun persist() {
        JsonFile.write(indexFile, mapOf("version" to 1L, "items" to state.value.map { it.toJson() }))
    }

    companion object {
        fun sanitizeFileName(name: String): String {
            val cleaned = name.map { c -> if (c.isLetterOrDigit() || c in "._- ()[]") c else '_' }.joinToString("").trim().trim('.')
            val limited = cleaned.take(120)
            return if (limited.isEmpty()) "file.bin" else limited
        }
    }
}
