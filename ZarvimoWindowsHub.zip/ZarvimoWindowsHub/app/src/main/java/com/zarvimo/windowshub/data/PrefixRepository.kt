package com.zarvimo.windowshub.data

import com.zarvimo.windowshub.core.FsUtil
import com.zarvimo.windowshub.core.PrefixSettings
import com.zarvimo.windowshub.core.optBoolean
import com.zarvimo.windowshub.core.optLong
import com.zarvimo.windowshub.core.optMap
import com.zarvimo.windowshub.core.optString
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** A Wine prefix ("environment"): one isolated fake Windows installation plus its settings. */
data class PrefixConfig(
    val id: String,
    val name: String,
    val runtimeId: String,
    val settings: PrefixSettings,
    val createdAt: Long,
    /** True only after wineboot finished successfully and wrote the registry files. */
    val initialized: Boolean,
    val lastError: String?,
) {
    fun toJson(): Map<String, Any?> = linkedMapOf(
        "id" to id,
        "name" to name,
        "runtimeId" to runtimeId,
        "display" to settings.display,
        "winedebug" to settings.winedebug,
        "extraEnv" to settings.extraEnv,
        "createdAt" to createdAt,
        "initialized" to initialized,
        "lastError" to lastError,
    )

    companion object {
        fun fromJson(m: Map<String, Any?>): PrefixConfig? {
            val id = m.optString("id") ?: return null
            val env = LinkedHashMap<String, String>()
            m.optMap("extraEnv")?.forEach { (k, v) -> if (v is String) env[k] = v }
            return PrefixConfig(
                id = id,
                name = m.optString("name") ?: id,
                runtimeId = m.optString("runtimeId") ?: return null,
                settings = PrefixSettings(
                    display = m.optString("display") ?: "",
                    winedebug = m.optString("winedebug") ?: "-all",
                    extraEnv = env,
                ),
                createdAt = m.optLong("createdAt"),
                initialized = m.optBoolean("initialized"),
                lastError = m.optString("lastError"),
            )
        }
    }
}

class PrefixRepository(private val paths: AppPaths) {
    private val lock = Any()
    private val state = MutableStateFlow<List<PrefixConfig>>(emptyList())
    val prefixes: StateFlow<List<PrefixConfig>> = state.asStateFlow()

    private fun configFile(id: String) = File(File(paths.prefixes, id), "config.json")

    /** The WINEPREFIX directory for an environment. */
    fun wineDir(id: String): File = File(File(paths.prefixes, id), "wine")

    fun find(id: String): PrefixConfig? = state.value.firstOrNull { it.id == id }

    fun load() = synchronized(lock) {
        val dirs = paths.prefixes.listFiles { f -> f.isDirectory } ?: emptyArray()
        state.value = dirs.mapNotNull { dir ->
            JsonFile.readObject(File(dir, "config.json"))?.let { PrefixConfig.fromJson(it) }
        }.filter { it.id.isNotEmpty() }.sortedBy { it.createdAt }
    }

    fun create(name: String, runtimeId: String, display: String): PrefixConfig {
        val config = PrefixConfig(
            id = newId(),
            name = name.trim().take(40),
            runtimeId = runtimeId,
            settings = PrefixSettings(display = display.trim()),
            createdAt = System.currentTimeMillis(),
            initialized = false,
            lastError = null,
        )
        wineDir(config.id).mkdirs()
        synchronized(lock) {
            JsonFile.write(configFile(config.id), config.toJson())
            state.value = state.value + config
        }
        return config
    }

    fun update(config: PrefixConfig) = synchronized(lock) {
        JsonFile.write(configFile(config.id), config.toJson())
        state.value = state.value.map { if (it.id == config.id) config else it }
    }

    fun markInitialized(id: String, ok: Boolean, error: String?) {
        val current = find(id) ?: return
        update(current.copy(initialized = ok, lastError = if (ok) null else error))
    }

    fun delete(id: String) {
        synchronized(lock) { state.value = state.value.filter { it.id != id } }
        FsUtil.deleteTreeNoFollow(File(paths.prefixes, id))
    }

    /**
     * Lists .exe files under "Program Files" and "Program Files (x86)" (up to 4 levels deep), skipping the
     * placeholder folders that Wine creates itself. Symlinks are not followed.
     */
    fun scanPrograms(id: String): List<File> {
        val driveC = File(wineDir(id), "drive_c")
        val found = ArrayList<File>()
        for (top in listOf("Program Files", "Program Files (x86)")) {
            walk(File(driveC, top), 0, found)
        }
        return found.sortedBy { it.absolutePath.lowercase() }
    }

    private fun walk(dir: File, depth: Int, out: MutableList<File>) {
        if (depth > 4 || out.size >= 300) return
        val children = dir.listFiles() ?: return
        for (c in children) {
            if (FsUtil.isSymlink(c)) continue
            if (c.isDirectory) {
                if (depth == 0 && c.name in WINE_STUB_FOLDERS) continue
                walk(c, depth + 1, out)
            } else if (c.name.endsWith(".exe", ignoreCase = true) && !c.name.startsWith("unins", ignoreCase = true)) {
                out.add(c)
            }
        }
    }

    companion object {
        private val WINE_STUB_FOLDERS = setOf(
            "Common Files", "Internet Explorer", "Windows Media Player", "Windows NT",
            "Windows Defender", "Windows Mail", "Windows Photo Viewer", "WindowsPowerShell",
        )
    }
}
