package com.zarvimo.windowshub.core

import org.apache.commons.compress.archivers.ArchiveEntry
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Platform operations that differ between Android (android.system.Os) and a plain JVM (used by unit tests). */
interface FileOps {
    @Throws(IOException::class)
    fun symlink(target: String, link: File)

    @Throws(IOException::class)
    fun chmod(file: File, mode: Int)
}

class ArchiveException(message: String, cause: Throwable? = null) : IOException(message, cause)

/**
 * Safe extraction of runtime packages: .tar, .tar.gz/.tgz, .tar.xz, .tar.bz2 and .zip (detected by content,
 * not by file name).
 *
 * Tar-based formats are streamed. A .zip has to be copied to a temporary file first, because its permission
 * bits and symlink flags live in the central directory at the end of the file.
 *
 * Safety rules enforced for every entry:
 *  - names are normalised; absolute paths and ".." are rejected (zip-slip / tar-slip);
 *  - the canonical parent directory must stay inside the destination (blocks writes through symlinks);
 *  - an existing symlink at the target path is removed rather than written through;
 *  - only regular files, directories, symlinks and hard links are materialised. Devices, FIFOs etc. are skipped.
 */
class ArchiveExtractor(private val ops: FileOps) {

    data class Result(val entries: Int, val files: Int, val bytes: Long, val skipped: Int)

    private enum class Format { TAR, TAR_GZ, TAR_XZ, TAR_BZ2, ZIP }

    /**
     * @param tempDir where a .zip is spooled to before extraction
     * @param progress called periodically with (entries so far, uncompressed bytes so far)
     * @param checkCancelled may throw (e.g. CancellationException) to abort extraction
     */
    fun extract(
        source: InputStream,
        dest: File,
        tempDir: File = File(System.getProperty("java.io.tmpdir") ?: "."),
        progress: (entries: Int, bytes: Long) -> Unit = { _, _ -> },
        checkCancelled: () -> Unit = {},
    ): Result {
        val input = BufferedInputStream(source, 128 * 1024)
        val format = sniff(input)
        dest.mkdirs()
        val state = ExtractState(dest.canonicalFile, progress, checkCancelled)

        if (format == Format.ZIP) {
            extractZip(input, tempDir, state, checkCancelled)
        } else {
            extractTar(input, format, state)
        }
        progress(state.entries, state.bytes)
        return Result(state.entries, state.files, state.bytes, state.skipped)
    }

    private class ExtractState(
        val destCanon: File,
        val progress: (Int, Long) -> Unit,
        val checkCancelled: () -> Unit,
    ) {
        var entries = 0
        var files = 0
        var skipped = 0
        var bytes = 0L
        var lastReport = 0L
        val buffer = ByteArray(64 * 1024)
    }

    // ---- tar family (streamed) ----

    private fun extractTar(input: BufferedInputStream, format: Format, state: ExtractState) {
        val archive: ArchiveInputStream<*> = try {
            when (format) {
                Format.TAR -> TarArchiveInputStream(input)
                Format.TAR_GZ -> TarArchiveInputStream(BufferedInputStream(GzipCompressorInputStream(input), 128 * 1024))
                Format.TAR_XZ -> TarArchiveInputStream(BufferedInputStream(XZCompressorInputStream(input), 128 * 1024))
                Format.TAR_BZ2 -> TarArchiveInputStream(BufferedInputStream(BZip2CompressorInputStream(input), 128 * 1024))
                Format.ZIP -> throw IllegalStateException("zip handled elsewhere")
            }
        } catch (e: IOException) {
            throw ArchiveException("Could not open the archive: ${e.message}", e)
        } catch (e: NoClassDefFoundError) {
            throw ArchiveException("This archive type needs a decompression library that is not available: ${e.message}", e)
        }

        archive.use { ais ->
            while (true) {
                state.checkCancelled()
                val entry: ArchiveEntry = try {
                    ais.nextEntry ?: break
                } catch (e: IOException) {
                    throw ArchiveException("The archive is damaged or not a valid ${format.name} file: ${e.message}", e)
                }
                handleEntry(entry, ais, state)
            }
        }
    }

    // ---- zip (needs random access) ----

    private fun extractZip(input: BufferedInputStream, tempDir: File, state: ExtractState, checkCancelled: () -> Unit) {
        tempDir.mkdirs()
        val spool = File.createTempFile("zarvimo-zip-", ".tmp", tempDir)
        try {
            FileOutputStream(spool).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    checkCancelled()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
            val zf = try {
                ZipFile.builder().setFile(spool).get()
            } catch (e: IOException) {
                throw ArchiveException("The zip file is damaged: ${e.message}", e)
            }
            zf.use { z ->
                val all = z.entries
                while (all.hasMoreElements()) {
                    state.checkCancelled()
                    val entry = all.nextElement()
                    z.getInputStream(entry).use { data -> handleEntry(entry, data, state) }
                }
            }
        } finally {
            spool.delete()
        }
    }

    // ---- shared per-entry logic ----

    /** @param data stream positioned at the start of this entry's content */
    private fun handleEntry(entry: ArchiveEntry, data: InputStream, state: ExtractState) {
        state.entries++

        val rel = FsUtil.normalizeEntryName(entry.name)
            ?: throw ArchiveException("Unsafe path in archive: \"${entry.name}\". Extraction aborted.")
        if (rel.isEmpty()) return

        val target = FsUtil.resolveInside(state.destCanon, rel)
            ?: throw ArchiveException("Archive entry \"${entry.name}\" would be written outside the runtime folder. Extraction aborted.")

        val tar = entry as? TarArchiveEntry
        val zip = entry as? ZipArchiveEntry

        val isSymlink = tar?.isSymbolicLink ?: zip?.isUnixSymlink ?: false
        val isHardLink = tar?.isLink ?: false
        val mode = tar?.mode ?: zip?.unixMode ?: 0

        when {
            entry.isDirectory -> {
                if (FsUtil.isSymlink(target)) Files.delete(target.toPath())
                if (!target.isDirectory && !target.mkdirs()) throw ArchiveException("Could not create directory $rel")
                ops.chmod(target, (mode and 0x1FF) or 0x1C0)
            }

            isSymlink -> {
                val linkTarget = if (tar != null) tar.linkName else readSmall(data).toString(Charsets.UTF_8)
                if (linkTarget.isEmpty() || linkTarget.contains('\u0000') || linkTarget.length > 4096) {
                    throw ArchiveException("Invalid symbolic link target for $rel")
                }
                target.parentFile?.mkdirs()
                removeExisting(target)
                ops.symlink(linkTarget, target)
            }

            isHardLink -> {
                val srcRel = FsUtil.normalizeEntryName(tar!!.linkName)
                    ?: throw ArchiveException("Unsafe hard link target for $rel")
                val src = FsUtil.resolveInside(state.destCanon, srcRel)
                if (src == null || !src.isFile || FsUtil.isSymlink(src)) {
                    throw ArchiveException("Hard link $rel points to a file that is not in the archive before it.")
                }
                target.parentFile?.mkdirs()
                removeExisting(target)
                Files.copy(src.toPath(), target.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
                state.files++
            }

            tar != null && !tar.isFile -> state.skipped++ // character/block device, FIFO, etc.

            else -> {
                target.parentFile?.mkdirs()
                removeExisting(target)
                FileOutputStream(target).use { out ->
                    while (true) {
                        state.checkCancelled()
                        val n = data.read(state.buffer)
                        if (n < 0) break
                        out.write(state.buffer, 0, n)
                        state.bytes += n
                        if (state.bytes - state.lastReport >= 512 * 1024) {
                            state.lastReport = state.bytes
                            state.progress(state.entries, state.bytes)
                        }
                    }
                }
                val perm = (mode and 0x1FF).let { if (it == 0) 0x1A4 else it } // default 0644
                ops.chmod(target, perm or 0x180) // always owner-readable/writable
                state.files++
            }
        }
    }

    private fun sniff(input: BufferedInputStream): Format {
        input.mark(1024)
        val head = ByteArray(512)
        var n = 0
        while (n < head.size) {
            val r = input.read(head, n, head.size - n)
            if (r < 0) break
            n += r
        }
        input.reset()

        fun at(i: Int, vararg v: Int): Boolean {
            if (n < i + v.size) return false
            for (k in v.indices) if ((head[i + k].toInt() and 0xFF) != v[k]) return false
            return true
        }

        return when {
            at(0, 0x1F, 0x8B) -> Format.TAR_GZ
            at(0, 0xFD, 0x37, 0x7A, 0x58, 0x5A, 0x00) -> Format.TAR_XZ
            at(0, 0x42, 0x5A, 0x68) -> Format.TAR_BZ2
            at(0, 0x50, 0x4B, 0x03, 0x04) || at(0, 0x50, 0x4B, 0x05, 0x06) -> Format.ZIP
            at(0, 0x28, 0xB5, 0x2F, 0xFD) ->
                throw ArchiveException("Zstandard (.zst) archives are not supported. Repack the runtime as .tar.xz, .tar.gz or .zip.")
            at(257, 0x75, 0x73, 0x74, 0x61, 0x72) -> Format.TAR // "ustar"
            else -> throw ArchiveException("Unrecognised archive format. Supported: .tar, .tar.gz, .tar.xz, .tar.bz2, .zip.")
        }
    }

    private fun readSmall(stream: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        while (true) {
            val n = stream.read(buffer)
            if (n < 0) break
            if (out.size() + n > 8192) throw ArchiveException("Symbolic link entry is unreasonably large.")
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    /** Removes an existing file or symlink at [target] so it can be replaced, but never an existing directory. */
    private fun removeExisting(target: File) {
        if (FsUtil.isSymlink(target) || target.isFile) {
            Files.delete(target.toPath())
        } else if (target.isDirectory) {
            throw ArchiveException("Archive tries to replace directory \"${target.name}\" with a file.")
        }
    }
}
