package com.zarvimo.windowshub.core

import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

object FsUtil {
    /**
     * Deletes a file or directory tree without ever following symbolic links.
     * (File.deleteRecursively would descend into a symlinked directory, which is unsafe for imported archives.)
     */
    fun deleteTreeNoFollow(root: File) {
        val path = root.toPath()
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return
        Files.walkFileTree(
            path,
            object : SimpleFileVisitor<Path>() {
                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    Files.delete(file) // regular files and symlinks (links are not followed)
                    return FileVisitResult.CONTINUE
                }

                override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                    if (exc != null) throw exc
                    Files.delete(dir)
                    return FileVisitResult.CONTINUE
                }
            },
        )
    }

    /**
     * Normalises an archive entry name to a safe relative path ("a/b/c"), or returns null if it is unsafe.
     * Returns "" for entries that denote the root itself ("." or "./").
     * Rejects absolute paths, ".." segments and NUL characters.
     */
    fun normalizeEntryName(raw: String): String? {
        if (raw.contains('\u0000')) return null
        val name = raw.replace('\\', '/')
        if (name.startsWith("/")) return null
        val parts = ArrayList<String>()
        for (seg in name.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> return null
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }

    /**
     * Resolves [relative] under [root]. Returns null if, after resolving any existing symlinks in the
     * parent chain, the target's parent would be outside [root].
     */
    fun resolveInside(root: File, relative: String): File? {
        val rootCanon = root.canonicalFile
        val target = File(rootCanon, relative)
        val parent = target.parentFile ?: return null
        val parentCanon = parent.canonicalFile
        val ok = parentCanon.path == rootCanon.path || parentCanon.path.startsWith(rootCanon.path + File.separator)
        return if (ok) target else null
    }

    fun isSymlink(file: File): Boolean = Files.isSymbolicLink(file.toPath())
}
