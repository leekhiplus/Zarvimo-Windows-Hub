package com.zarvimo.windowshub.data

import android.content.Context
import android.system.ErrnoException
import android.system.Os
import com.zarvimo.windowshub.core.FileOps
import com.zarvimo.windowshub.core.JsonException
import com.zarvimo.windowshub.core.MiniJson
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** All directories the app owns. Everything lives in app-private storage. */
class AppPaths(context: Context) {
    val root: File = context.filesDir
    val library = File(root, "library")
    val runtimes = File(root, "runtimes")
    val staging = File(root, "runtimes/.staging")
    val prefixes = File(root, "prefixes")
    val home = File(root, "home")
    val logs = File(root, "logs")
    val tmp = File(context.cacheDir, "tmp")

    fun ensure() {
        for (d in listOf(library, runtimes, prefixes, home, logs, tmp)) d.mkdirs()
    }
}

/** android.system.Os-backed file operations (symlinks and exact permission bits). */
object AndroidFileOps : FileOps {
    override fun symlink(target: String, link: File) {
        try {
            Os.symlink(target, link.absolutePath)
        } catch (e: ErrnoException) {
            throw IOException("Could not create symlink ${link.name}: ${e.message}", e)
        }
    }

    override fun chmod(file: File, mode: Int) {
        try {
            Os.chmod(file.absolutePath, mode)
        } catch (e: ErrnoException) {
            throw IOException("Could not set permissions on ${file.name}: ${e.message}", e)
        }
    }
}

/** Small atomic JSON file helper. */
object JsonFile {
    fun readObject(file: File): Map<String, Any?>? {
        if (!file.isFile) return null
        return try {
            MiniJson.parseObject(file.readText())
        } catch (_: JsonException) {
            null
        } catch (_: IOException) {
            null
        }
    }

    fun write(file: File, value: Any?) {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        tmp.writeText(MiniJson.stringify(value, pretty = true))
        Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
    }
}

fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(12)
