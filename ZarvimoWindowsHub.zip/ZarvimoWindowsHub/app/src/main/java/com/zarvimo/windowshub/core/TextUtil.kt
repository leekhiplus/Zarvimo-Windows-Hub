package com.zarvimo.windowshub.core

import java.util.Locale

object WindowsPath {
    /**
     * Converts an absolute Unix path to the Wine path under the default Z: drive, which Wine maps to "/".
     * Used for programs (such as msiexec) that expect a DOS-style path argument.
     */
    fun fromUnix(path: String): String {
        require(path.startsWith("/")) { "Expected an absolute path: $path" }
        return "Z:" + path.replace('/', '\\')
    }
}

/**
 * Splits a user-typed argument string into arguments.
 * Whitespace separates arguments; single or double quotes group text. Backslashes are literal,
 * so Windows paths such as C:\Games\app.exe survive unchanged.
 */
object ArgTokenizer {
    fun split(input: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var inToken = false
        var quote: Char? = null
        for (c in input) {
            val q = quote
            when {
                q != null -> if (c == q) quote = null else cur.append(c)
                c == '"' || c == '\'' -> {
                    quote = c
                    inToken = true
                }
                c.isWhitespace() -> if (inToken) {
                    out.add(cur.toString())
                    cur.setLength(0)
                    inToken = false
                }
                else -> {
                    cur.append(c)
                    inToken = true
                }
            }
        }
        if (quote != null) throw IllegalArgumentException("Unterminated quote in arguments")
        if (inToken) out.add(cur.toString())
        return out
    }
}

/** Parses "KEY=VALUE" lines for per-prefix environment variables. */
object EnvText {
    private val KEY = Regex("^[A-Za-z_][A-Za-z0-9_]*$")

    /** @throws IllegalArgumentException with a line-numbered message on invalid input. */
    fun parse(text: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        text.lines().forEachIndexed { index, raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed
            val eq = line.indexOf('=')
            if (eq <= 0) throw IllegalArgumentException("Line ${index + 1}: expected KEY=VALUE")
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1)
            if (!KEY.matches(key)) throw IllegalArgumentException("Line ${index + 1}: invalid variable name '$key'")
            if (value.contains('\u0000')) throw IllegalArgumentException("Line ${index + 1}: value contains a NUL character")
            out[key] = value
        }
        return out
    }

    fun format(env: Map<String, String>): String = env.entries.joinToString("\n") { "${it.key}=${it.value}" }
}

object ByteFormat {
    fun human(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unit = -1
        while (value >= 1024 && unit < units.size - 1) {
            value /= 1024
            unit++
        }
        return String.format(Locale.US, "%.1f %s", value, units[unit])
    }
}

/**
 * Expands "{token}" placeholders in runtime command templates.
 * An element that is exactly "{wine-args}" expands to several elements (the Wine arguments).
 * Unknown tokens are an error rather than being passed through, so a typo can never launch the wrong thing.
 */
object CommandTemplate {
    const val WINE_ARGS = "{wine-args}"
    private val TOKEN = Regex("\\{([a-z][a-z-]*)\\}")

    fun expandString(template: String, tokens: Map<String, String>): String =
        TOKEN.replace(template) { m ->
            val name = m.groupValues[1]
            tokens[name] ?: throw IllegalArgumentException("Unknown or unavailable placeholder {$name}")
        }

    fun expand(template: List<String>, tokens: Map<String, String>, wineArgs: List<String>): List<String> {
        val out = ArrayList<String>()
        for (element in template) {
            if (element == WINE_ARGS) {
                out.addAll(wineArgs)
            } else {
                if (element.contains("wine-args")) {
                    throw IllegalArgumentException("{wine-args} must be a standalone element in the command template")
                }
                out.add(expandString(element, tokens))
            }
        }
        return out
    }
}
