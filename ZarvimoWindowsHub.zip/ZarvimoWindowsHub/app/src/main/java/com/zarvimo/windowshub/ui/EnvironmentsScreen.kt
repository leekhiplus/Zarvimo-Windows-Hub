package com.zarvimo.windowshub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.core.EnvText
import com.zarvimo.windowshub.core.WineTool
import com.zarvimo.windowshub.data.PrefixConfig

@Composable
fun EnvironmentsScreen(vm: MainViewModel) {
    val prefixes by vm.prefixes.collectAsStateWithLifecycle()
    val runtimes by vm.runtimes.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()

    var showCreate by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<PrefixConfig?>(null) }
    var deleteTarget by remember { mutableStateOf<PrefixConfig?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Environments",
            "Each environment is a separate Wine prefix: its own fake C: drive, registry and installed programs.",
        ) {
            Button(onClick = { showCreate = true }) { Text("New environment") }
        }
        if (prefixes.isEmpty()) {
            InfoCard(
                "No environments",
                if (runtimes.any { it.manifest != null }) "Create an environment, then initialize it with the installed runtime."
                else "An environment needs a Wine runtime. Install a runtime package on the Runtimes tab first. Zarvimo does not ship Wine itself.",
            )
        } else {
            LazyColumn(contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(prefixes, key = { it.id }) { p ->
                    val runtime = runtimes.firstOrNull { it.id == p.runtimeId }
                    val running = sessions.count { it.prefixId == p.id && it.status == com.zarvimo.windowshub.runtime.SessionStatus.RUNNING }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Tag(if (p.initialized) "Initialized" else "Not initialized", warn = !p.initialized)
                                if (running > 0) Tag("$running running")
                                if (runtime?.manifest == null) Tag("Runtime missing", warn = true)
                            }
                            KeyValue("Runtime", runtime?.manifest?.let { "${it.name} ${it.version}" } ?: p.runtimeId)
                            KeyValue("X11 display", p.settings.display.ifBlank { "none configured" })
                            p.lastError?.let { Text("Last initialization problem: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!p.initialized) {
                                    Button(onClick = { vm.initializePrefix(p.id) }) { Text("Initialize") }
                                } else {
                                    OutlinedButton(onClick = { vm.scanPrefix(p.id) }) { Text("Installed programs") }
                                }
                                OutlinedButton(onClick = { editTarget = p }) { Text("Settings") }
                            }
                            if (p.initialized) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { vm.runTool(p.id, WineTool.WINECFG) }) { Text("winecfg") }
                                    OutlinedButton(onClick = { vm.runTool(p.id, WineTool.REGEDIT) }) { Text("regedit") }
                                }
                            }
                            TextButton(onClick = { deleteTarget = p }) { Text("Delete environment") }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) CreateDialog(vm, onDismiss = { showCreate = false })
    editTarget?.let { p -> SettingsDialog(vm, p, onDismiss = { editTarget = null }) }
    deleteTarget?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete \"${p.name}\"?") },
            text = { Text("This permanently deletes the environment's whole fake C: drive, registry and every program installed in it. Running processes in it are stopped first.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePrefix(p.id)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun CreateDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val runtimes by vm.runtimes.collectAsStateWithLifecycle()
    val usable = runtimes.filter { it.manifest != null }
    var name by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("127.0.0.1:0") }
    var runtimeId by remember { mutableStateOf(usable.firstOrNull()?.id) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New environment") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                Text("Runtime", style = MaterialTheme.typography.labelLarge)
                if (usable.isEmpty()) Text("No valid runtime installed. Install one on the Runtimes tab first.", color = MaterialTheme.colorScheme.error)
                usable.forEach { r ->
                    val m = r.manifest!!
                    RadioRow(runtimeId == r.id, { runtimeId = r.id }) {
                        Text("${m.name} ${m.version}", fontWeight = FontWeight.Medium)
                        Text(
                            "Wine ${m.wineVersion} · runs ${m.windowsMachines.joinToString { it.label }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                OutlinedTextField(
                    display,
                    { display = it },
                    singleLine = true,
                    label = { Text("X11 display (TCP)") },
                    supportingText = { Text("Needed for graphical programs. Zarvimo has no built-in X server; an X server app must listen on this address. Leave empty for console programs only.") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = runtimeId != null && name.isNotBlank(),
                onClick = {
                    if (vm.createPrefix(name, runtimeId!!, display)) onDismiss()
                },
            ) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SettingsDialog(vm: MainViewModel, p: PrefixConfig, onDismiss: () -> Unit) {
    var name by remember(p.id) { mutableStateOf(p.name) }
    var display by remember(p.id) { mutableStateOf(p.settings.display) }
    var debug by remember(p.id) { mutableStateOf(p.settings.winedebug) }
    var env by remember(p.id) { mutableStateOf(EnvText.format(p.settings.extraEnv)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Environment settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    display,
                    { display = it },
                    singleLine = true,
                    label = { Text("X11 display (TCP)") },
                    supportingText = { Text("host:number, e.g. 127.0.0.1:0 means TCP port 6000.") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    debug,
                    { debug = it },
                    singleLine = true,
                    label = { Text("WINEDEBUG") },
                    supportingText = { Text("-all silences Wine's debug output. Use e.g. err+all,warn+module to diagnose problems.") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    env,
                    { env = it },
                    label = { Text("Extra environment variables") },
                    supportingText = { Text("One KEY=VALUE per line. These override the runtime's defaults.") },
                    modifier = Modifier.fillMaxWidth().height(140.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (vm.updatePrefix(p.id, name, display, debug, env)) onDismiss() }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Dialog listing .exe files found inside an initialized environment. */
@Composable
fun ScanDialog(vm: MainViewModel, prefixId: String, files: List<java.io.File>, onDismiss: () -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    val inLibrary = library.map { it.path }.toSet()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Installed programs") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (files.isEmpty()) {
                    Text("No .exe files were found under Program Files. Programs installed elsewhere, or installers that are still running, will not show up here.")
                }
                files.forEach { f ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, fontWeight = FontWeight.Medium)
                            Text(
                                f.absolutePath.substringAfter("drive_c/"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (f.absolutePath in inLibrary) {
                            Tag("In library")
                        } else {
                            TextButton(onClick = { vm.addScannedProgram(prefixId, f) }) { Text("Add") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
