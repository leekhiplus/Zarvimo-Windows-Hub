package com.zarvimo.windowshub.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0B6E69),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBFF0EA),
    onPrimaryContainer = Color(0xFF00201E),
    secondary = Color(0xFF0B1F3A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD8E3F8),
    onSecondaryContainer = Color(0xFF001A3D),
    background = Color(0xFFFBFCFE),
    surface = Color(0xFFFBFCFE),
    surfaceVariant = Color(0xFFE3E8EF),
    onSurfaceVariant = Color(0xFF43474E),
    error = Color(0xFFB3261E),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5EEAD4),
    onPrimary = Color(0xFF003733),
    primaryContainer = Color(0xFF00504B),
    onPrimaryContainer = Color(0xFFBFF0EA),
    secondary = Color(0xFFB4C7E8),
    onSecondary = Color(0xFF0B1F3A),
    secondaryContainer = Color(0xFF263B5C),
    onSecondaryContainer = Color(0xFFD8E3F8),
    background = Color(0xFF0F1623),
    surface = Color(0xFF0F1623),
    surfaceVariant = Color(0xFF1E2736),
    onSurfaceVariant = Color(0xFFC3C7CF),
    error = Color(0xFFF2B8B5),
)

@Composable
fun ZarvimoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
