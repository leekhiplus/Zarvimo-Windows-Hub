package com.zarvimo.windowshub.core

import java.net.InetSocketAddress
import java.net.Socket

/**
 * An X11 display reachable over TCP, e.g. "127.0.0.1:0" (TCP port 6000).
 *
 * Zarvimo does not contain an X server. GUI Windows programs need one running elsewhere
 * (for example an Android X-server app that accepts TCP connections).
 * Unix-socket displays are not supported because other apps' sockets are not reachable from this app.
 */
data class DisplaySpec(val host: String, val display: Int) {
    val port: Int get() = 6000 + display

    /** Value for the DISPLAY variable. Always includes the host so X clients use TCP, not a Unix socket. */
    val envValue: String get() = "$host:$display"

    companion object {
        private val HOST = Regex("^[A-Za-z0-9.-]+$")

        /** Accepts "host:N", "host:N.S" or ":N" (host defaults to 127.0.0.1). Returns null if unsupported or invalid. */
        fun parse(text: String): DisplaySpec? {
            val t = text.trim()
            if (t.isEmpty() || t.startsWith("/") || t.startsWith("unix:")) return null
            val colon = t.lastIndexOf(':')
            if (colon < 0) return null
            val hostPart = t.substring(0, colon).ifEmpty { "127.0.0.1" }
            var rest = t.substring(colon + 1)
            val dot = rest.indexOf('.')
            if (dot >= 0) rest = rest.substring(0, dot)
            val number = rest.toIntOrNull() ?: return null
            if (number !in 0..99) return null
            if (!HOST.matches(hostPart)) return null
            return DisplaySpec(hostPart, number)
        }
    }
}

object DisplayProbe {
    /** True only if a TCP connection to the X server port succeeds. This proves a listener exists, not that it is a healthy X server. */
    fun isReachable(spec: DisplaySpec, timeoutMs: Int = 1500): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(spec.host, spec.port), timeoutMs)
            true
        }
    } catch (_: Exception) {
        false
    }
}
