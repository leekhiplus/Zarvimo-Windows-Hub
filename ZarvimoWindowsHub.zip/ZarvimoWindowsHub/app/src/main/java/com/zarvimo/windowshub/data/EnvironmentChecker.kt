package com.zarvimo.windowshub.data

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.util.concurrent.TimeUnit

sealed interface ExecCheck {
    data object Allowed : ExecCheck
    data class Blocked(val detail: String) : ExecCheck
    data class Unavailable(val detail: String) : ExecCheck
}

data class EnvironmentReport(
    val androidRelease: String,
    val sdkInt: Int,
    val supportedAbis: List<String>,
    val appTargetSdk: Int,
    val freeBytes: Long,
    val totalRamBytes: Long,
    val exec: ExecCheck,
)

/** Reports facts about this device and performs one real test: can an app-storage binary be executed? */
class EnvironmentChecker(private val context: Context, private val paths: AppPaths) {

    fun run(): EnvironmentReport {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        return EnvironmentReport(
            androidRelease = Build.VERSION.RELEASE ?: "?",
            sdkInt = Build.VERSION.SDK_INT,
            supportedAbis = Build.SUPPORTED_ABIS.toList(),
            appTargetSdk = context.applicationInfo.targetSdkVersion,
            freeBytes = paths.root.usableSpace,
            totalRamBytes = mem.totalMem,
            exec = testExecFromAppStorage(),
        )
    }

    /**
     * Copies the system's toybox binary into app storage and tries to run it from there.
     * Runtimes are native executables stored in app storage, so if this fails no runtime can ever launch.
     */
    private fun testExecFromAppStorage(): ExecCheck {
        val source = File("/system/bin/toybox")
        if (!source.isFile) return ExecCheck.Unavailable("/system/bin/toybox is not present, so the test could not be run.")
        val dir = File(paths.tmp, "exec-test").apply { mkdirs() }
        val copy = File(dir, "toybox")
        return try {
            source.inputStream().use { i -> copy.outputStream().use { o -> i.copyTo(o) } }
            copy.setExecutable(true, true)
            val process = ProcessBuilder(copy.absolutePath, "echo", "zarvimo-exec-ok")
                .redirectErrorStream(true)
                .start()
            val finished = process.waitFor(5, TimeUnit.SECONDS)
            val output = process.inputStream.bufferedReader().readText().trim()
            if (!finished) {
                process.destroyForcibly()
                ExecCheck.Unavailable("The test process did not finish in time.")
            } else if (output.contains("zarvimo-exec-ok")) {
                ExecCheck.Allowed
            } else {
                ExecCheck.Unavailable("The test binary ran but produced unexpected output: ${output.take(120)}")
            }
        } catch (e: java.io.IOException) {
            val msg = e.message ?: "I/O error"
            if (msg.contains("error=13") || msg.contains("Permission denied", ignoreCase = true)) {
                ExecCheck.Blocked("Android refused to execute a file from app storage (${msg.take(160)}). Runtimes cannot launch on this device.")
            } else {
                ExecCheck.Unavailable("Test failed: ${msg.take(160)}")
            }
        } finally {
            copy.delete()
        }
    }
}
