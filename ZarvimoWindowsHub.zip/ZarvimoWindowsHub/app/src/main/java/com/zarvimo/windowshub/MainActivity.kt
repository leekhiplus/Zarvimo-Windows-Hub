package com.zarvimo.windowshub

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.zarvimo.windowshub.ui.ZarvimoRoot
import com.zarvimo.windowshub.ui.ZarvimoTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ZarvimoTheme {
                ZarvimoRoot(vm)
            }
        }
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** "Open with" / "Share" of a .exe or .msi file imports it into the library. */
    private fun handleIntent(incoming: Intent?) {
        val i = incoming ?: return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_VIEW -> listOfNotNull(i.data)
            Intent.ACTION_SEND -> listOfNotNull(streamExtra(i))
            else -> emptyList()
        }
        if (uris.isNotEmpty()) vm.importFiles(uris)
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra(Intent.EXTRA_STREAM)
}
