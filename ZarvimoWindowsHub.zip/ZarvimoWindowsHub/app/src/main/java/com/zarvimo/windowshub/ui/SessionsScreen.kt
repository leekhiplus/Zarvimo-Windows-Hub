package com.zarvimo.windowshub.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.runtime.SessionInfo
import com.zarvimo.windowshub.runtime.SessionStatus
import java.text.DateFormat
import java.util.Date

@Composable
fun SessionsScreen(vm: MainViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val open by vm.openSession.collectAsStateWithLifecycle()

    val current = open?.let { id -> sessions.firstOrNull { it.id == id } }
    if (current != null) {
        BackHandler { vm.openSessionLog(null) }
        SessionLog(vm, current)
        return
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Sessions", "Real processes started by Zarvimo, with their output. The list is cleared when the app process ends.") {
            if (sessions.any { it.status != SessionStatus.RUNNING }) {
                OutlinedButton(onClick = { vm.clearFinishedSessions() }) { Text("Clear finished") }
            }
        }
        if (sessions.isEmpty()) {
            InfoCard("No sessions", "Start a program, an installer, an environment initialization or a runtime version check and its live output appears here.")
        } else {
            LazyColumn(contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(sessions.sortedByDescending { it.startedAt }, key = { it.id }) { s ->
                    Card(Modifier.fillMaxWidth().clickable { vm.openSessionLog(s.id) }) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(s.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Tag(statusText(s), warn = s.status == SessionStatus.FAILED_TO_START || (s.status == SessionStatus.EXITED && s.exitCode != 0))
                            }
                            Text("Started " + DateFormat.getTimeInstance().format(Date(s.startedAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (s.status == SessionStatus.RUNNING) {
                                TextButton(onClick = { vm.stopSession(s.id) }) { Text("Stop") }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun statusText(s: SessionInfo): String = when (s.status) {
    SessionStatus.RUNNING -> "Running"
    SessionStatus.EXITED -> "Exited with code ${s.exitCode}"
    SessionStatus.STOPPED -> "Stopped by you"
    SessionStatus.FAILED_TO_START -> "Failed to start"
}

@Composable
private fun SessionLog(vm: MainViewModel, s: SessionInfo) {
    val context = LocalContext.current
    val flow = remember(s.id) { vm.logFlow(s.id) }
    val lines = flow?.collectAsStateWithLifecycle()?.value ?: emptyList()
    val listState = rememberLazyListState()

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.lastIndex)
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(s.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(statusText(s), warn = s.status == SessionStatus.FAILED_TO_START || (s.status == SessionStatus.EXITED && s.exitCode != 0))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.openSessionLog(null) }) { Text("Back") }
                if (s.status == SessionStatus.RUNNING) {
                    Button(onClick = { vm.stopSession(s.id) }) { Text("Stop") }
                }
                OutlinedButton(onClick = {
                    vm.loadLogForSharing(s.id) { text ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Zarvimo log: ${s.title}")
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, "Share log"))
                    }
                }) { Text("Share log") }
            }
        }
        if (flow == null) {
            InfoCard("Log unavailable", "This session's output is no longer in memory.")
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(8.dp),
            ) {
                items(lines.size) { i -> MonoText(lines[i], Modifier.fillMaxWidth()) }
            }
        }
    }
}
