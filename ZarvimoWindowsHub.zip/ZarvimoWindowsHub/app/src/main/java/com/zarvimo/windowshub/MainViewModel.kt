package com.zarvimo.windowshub

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.windowshub.core.ArgTokenizer
import com.zarvimo.windowshub.core.ByteFormat
import com.zarvimo.windowshub.core.DisplayProbe
import com.zarvimo.windowshub.core.DisplaySpec
import com.zarvimo.windowshub.core.EnvText
import com.zarvimo.windowshub.core.FileKind
import com.zarvimo.windowshub.core.LaunchPlanner
import com.zarvimo.windowshub.core.PeInspector
import com.zarvimo.windowshub.core.PlanContext
import com.zarvimo.windowshub.core.PlanResult
import com.zarvimo.windowshub.core.PrefixSettings
import com.zarvimo.windowshub.core.WineJob
import com.zarvimo.windowshub.core.WineTool
import com.zarvimo.windowshub.data.EnvironmentReport
import com.zarvimo.windowshub.data.ImportRejectedException
import com.zarvimo.windowshub.data.LibraryItem
import com.zarvimo.windowshub.data.PrefixConfig
import com.zarvimo.windowshub.data.RuntimeImportException
import com.zarvimo.windowshub.runtime.SessionInfo
import com.zarvimo.windowshub.runtime.SessionStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

enum class Tab(val label: String) {
    LIBRARY("Library"),
    ENVIRONMENTS("Environments"),
    RUNTIMES("Runtimes"),
    SESSIONS("Sessions"),
    ABOUT("Status"),
}

data class OpProgress(val title: String, val detail: String, val fraction: Float?)

/** A message the user must read (a refusal, an error, or a summary). */
data class Notice(val title: String, val lines: List<String>)

data class ScanResult(val prefixId: String, val files: List<File>)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as ZarvimoApp).container
    private val resolver = app.contentResolver

    val library = c.library.items
    val runtimes = c.runtimes.runtimes
    val prefixes = c.prefixes.prefixes
    val sessions = c.sessions.sessions
    val deviceAbis: List<String> = c.deviceAbis

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> get() = _loaded

    private val _tab = MutableStateFlow(Tab.LIBRARY)
    val tab: StateFlow<Tab> get() = _tab

    private val _openSession = MutableStateFlow<String?>(null)
    val openSession: StateFlow<String?> get() = _openSession

    private val _progress = MutableStateFlow<OpProgress?>(null)
    val progress: StateFlow<OpProgress?> get() = _progress

    private val _notice = MutableStateFlow<Notice?>(null)
    val notice: StateFlow<Notice?> get() = _notice

    private val _envReport = MutableStateFlow<EnvironmentReport?>(null)
    val envReport: StateFlow<EnvironmentReport?> get() = _envReport

    private val _envChecking = MutableStateFlow(false)
    val envChecking: StateFlow<Boolean> get() = _envChecking

    private val _scan = MutableStateFlow<ScanResult?>(null)
    val scan: StateFlow<ScanResult?> get() = _scan

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> get() = _messages

    private var opJob: Job? = null
    private var lastProgressNanos = 0L

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                c.loadAll()
            } catch (e: Exception) {
                showNotice("Could not read saved data", listOf(e.message ?: e.javaClass.simpleName))
            }
            _loaded.value = true
            refreshEnvironment()
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Small UI-state helpers
    // ---------------------------------------------------------------------------------------------

    fun selectTab(t: Tab) {
        _tab.value = t
    }

    fun openSessionLog(id: String?) {
        _openSession.value = id
    }

    fun dismissNotice() {
        _notice.value = null
    }

    fun dismissScan() {
        _scan.value = null
    }

    fun cancelOperation() {
        opJob?.cancel()
    }

    private fun say(text: String) {
        _messages.tryEmit(text)
    }

    private fun showNotice(title: String, lines: List<String>) {
        _notice.value = Notice(title, lines)
    }

    private fun updateProgress(detail: String, fraction: Float?, force: Boolean = false) {
        val now = System.nanoTime()
        if (!force && now - lastProgressNanos < 100_000_000L) return
        lastProgressNanos = now
        _progress.update { it?.copy(detail = detail, fraction = fraction) }
    }

    /** Runs a long operation with a cancellable progress dialog. Only one runs at a time. */
    private fun runOp(title: String, block: suspend CoroutineScope.() -> Unit) {
        if (_progress.value != null) {
            say("Another operation is still running.")
            return
        }
        _progress.value = OpProgress(title, "", null)
        opJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                _loaded.first { it }
                block()
            } catch (e: CancellationException) {
                say("$title cancelled.")
            } catch (e: Exception) {
                showNotice("$title failed", listOf(e.message ?: e.javaClass.simpleName))
            } finally {
                _progress.value = null
            }
        }
    }

    private fun describe(uri: Uri): Pair<String, Long> {
        var name: String? = null
        var size = -1L
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !cur.isNull(ni)) name = cur.getString(ni)
                    val si = cur.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si)
                }
            }
        } catch (_: Exception) {
            // fall through to the URI's last path segment
        }
        return (name ?: uri.lastPathSegment ?: "file") to size
    }

    // ---------------------------------------------------------------------------------------------
    // Device / environment check
    // ---------------------------------------------------------------------------------------------

    fun refreshEnvironment() {
        if (_envChecking.value) return
        _envChecking.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _envReport.value = c.environment.run()
            } catch (e: Exception) {
                showNotice("Environment check failed", listOf(e.message ?: e.javaClass.simpleName))
            } finally {
                _envChecking.value = false
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Library
    // ---------------------------------------------------------------------------------------------

    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        runOp("Importing files") {
            val problems = ArrayList<String>()
            var ok = 0
            for ((index, uri) in uris.withIndex()) {
                val (name, size) = describe(uri)
                val label = "$name  (${index + 1} of ${uris.size})"
                updateProgress(label, null, force = true)
                try {
                    c.library.importStream(
                        displayName = name,
                        expectedSize = size,
                        open = { resolver.openInputStream(uri) ?: throw IOException("Cannot open $name") },
                        progress = { bytes ->
                            updateProgress(
                                "$label · ${ByteFormat.human(bytes)}",
                                if (size > 0) (bytes.toFloat() / size).coerceIn(0f, 1f) else null,
                            )
                        },
                        checkCancelled = { ensureActive() },
                    )
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: ImportRejectedException) {
                    problems.add(e.message ?: "Rejected: $name")
                } catch (e: Exception) {
                    problems.add("$name: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            when {
                problems.isEmpty() -> say(if (ok == 1) "Imported 1 file." else "Imported $ok files.")
                ok > 0 -> showNotice("Imported $ok, skipped ${problems.size}", problems)
                else -> showNotice("Nothing was imported", problems)
            }
        }
    }

    fun renameItem(id: String, name: String) {
        viewModelScope.launch(Dispatchers.IO) { c.library.rename(id, name) }
    }

    fun removeItem(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            c.library.remove(id)
            say("Removed from library.")
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Runtimes
    // ---------------------------------------------------------------------------------------------

    fun installRuntime(uri: Uri) {
        runOp("Installing runtime") {
            val (name, size) = describe(uri)
            updateProgress("Reading $name", null, force = true)
            try {
                val manifest = c.runtimes.install(
                    open = { resolver.openInputStream(uri) ?: throw IOException("Cannot open $name") },
                    archiveSize = size,
                    progress = { entries, bytes ->
                        updateProgress("$entries entries · ${ByteFormat.human(bytes)} extracted", null)
                    },
                    checkCancelled = { ensureActive() },
                )
                say("Runtime installed: ${manifest.name} ${manifest.version}")
            } catch (e: CancellationException) {
                throw e
            } catch (e: RuntimeImportException) {
                showNotice("Runtime not installed", listOf(e.message ?: "Rejected."))
            } catch (e: IOException) {
                showNotice("Runtime not installed", listOf(e.message ?: "I/O error while extracting."))
            }
        }
    }

    fun removeRuntime(id: String) {
        val users = prefixes.value.filter { it.runtimeId == id }
        if (users.isNotEmpty()) {
            showNotice(
                "Runtime is in use",
                listOf("Delete these environments first: " + users.joinToString { it.name }),
            )
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            c.runtimes.remove(id)
            say("Runtime removed.")
        }
    }

    /** Runs "<runtime command> --version" so the user can see whether the runtime executes at all. */
    fun checkRuntime(runtimeId: String) {
        viewModelScope.launch(Dispatchers.IO) { startWine(runtimeId, null, WineJob.VersionCheck) }
    }

    // ---------------------------------------------------------------------------------------------
    // Environments (Wine prefixes)
    // ---------------------------------------------------------------------------------------------

    fun createPrefix(name: String, runtimeId: String, display: String): Boolean {
        val n = name.trim()
        if (n.isEmpty()) {
            showNotice("Name required", listOf("Give the environment a name."))
            return false
        }
        if (display.isNotBlank() && DisplaySpec.parse(display) == null) {
            showNotice("Invalid display", listOf("Use host:number, for example 127.0.0.1:0. Only TCP displays are supported."))
            return false
        }
        if (runtimes.value.firstOrNull { it.id == runtimeId }?.manifest == null) {
            showNotice("Runtime required", listOf("Choose an installed, valid runtime."))
            return false
        }
        viewModelScope.launch(Dispatchers.IO) { c.prefixes.create(n, runtimeId, display) }
        return true
    }

    fun updatePrefix(id: String, name: String, display: String, winedebug: String, envText: String): Boolean {
        val current = c.prefixes.find(id) ?: return false
        val n = name.trim()
        if (n.isEmpty()) {
            showNotice("Name required", listOf("Give the environment a name."))
            return false
        }
        if (display.isNotBlank() && DisplaySpec.parse(display) == null) {
            showNotice("Invalid display", listOf("Use host:number, for example 127.0.0.1:0. Only TCP displays are supported."))
            return false
        }
        val env = try {
            EnvText.parse(envText)
        } catch (e: IllegalArgumentException) {
            showNotice("Invalid environment variables", listOf(e.message ?: "Invalid input."))
            return false
        }
        val updated = current.copy(
            name = n.take(40),
            settings = PrefixSettings(display = display.trim(), winedebug = winedebug.trim().ifEmpty { "-all" }, extraEnv = env),
        )
        viewModelScope.launch(Dispatchers.IO) { c.prefixes.update(updated) }
        return true
    }

    fun initializePrefix(prefixId: String) {
        val prefix = c.prefixes.find(prefixId) ?: return
        viewModelScope.launch(Dispatchers.IO) { startWine(prefix.runtimeId, prefix, WineJob.InitPrefix) }
    }

    fun runTool(prefixId: String, tool: WineTool) {
        val prefix = c.prefixes.find(prefixId) ?: return
        viewModelScope.launch(Dispatchers.IO) { startWine(prefix.runtimeId, prefix, WineJob.RunTool(tool)) }
    }

    fun deletePrefix(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            c.sessions.stopForPrefix(id)
            var waited = 0
            while (c.sessions.isPrefixBusy(id) && waited < 60) {
                delay(100)
                waited++
            }
            if (c.sessions.isPrefixBusy(id)) {
                showNotice("Environment is busy", listOf("A process in this environment did not stop. Stop it on the Sessions tab and try again."))
                return@launch
            }
            c.library.removeForPrefix(id)
            c.prefixes.delete(id)
            say("Environment deleted.")
        }
    }

    fun scanPrefix(prefixId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _scan.value = ScanResult(prefixId, c.prefixes.scanPrograms(prefixId))
        }
    }

    fun addScannedProgram(prefixId: String, file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                c.library.addPrefixProgram(prefixId, file)
                say("Added ${file.name} to the library.")
            } catch (e: ImportRejectedException) {
                say(e.message ?: "Could not add.")
            } catch (e: IOException) {
                say("Could not add: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Launching
    // ---------------------------------------------------------------------------------------------

    fun runProgram(item: LibraryItem, prefixId: String, argsText: String) {
        val args = try {
            ArgTokenizer.split(argsText)
        } catch (e: IllegalArgumentException) {
            showNotice("Invalid arguments", listOf(e.message ?: "Check the quotes."))
            return
        }
        val prefix = c.prefixes.find(prefixId) ?: run {
            showNotice("Cannot launch", listOf("That environment no longer exists."))
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(item.path)
            if (!file.isFile) {
                showNotice("Cannot launch", listOf("The file is missing from storage: ${item.fileName}"))
                return@launch
            }
            // Re-read the headers now rather than trusting what was stored at import time.
            startWine(prefix.runtimeId, prefix, WineJob.RunProgram(file, PeInspector.inspect(file), args))
        }
    }

    fun installMsi(item: LibraryItem, prefixId: String, quiet: Boolean, extraArgsText: String) {
        val args = try {
            ArgTokenizer.split(extraArgsText)
        } catch (e: IllegalArgumentException) {
            showNotice("Invalid arguments", listOf(e.message ?: "Check the quotes."))
            return
        }
        val prefix = c.prefixes.find(prefixId) ?: run {
            showNotice("Cannot launch", listOf("That environment no longer exists."))
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(item.path)
            if (!file.isFile) {
                showNotice("Cannot launch", listOf("The file is missing from storage: ${item.fileName}"))
                return@launch
            }
            if (PeInspector.inspect(file).kind != FileKind.MSI) {
                showNotice("Cannot install", listOf("${item.fileName} is not a Windows Installer package."))
                return@launch
            }
            startWine(prefix.runtimeId, prefix, WineJob.InstallMsi(file, quiet, args))
        }
    }

    private suspend fun startWine(runtimeId: String, prefix: PrefixConfig?, job: WineJob) {
        val entry = c.runtimes.find(runtimeId)
        val manifest = entry?.manifest
        if (entry == null || manifest == null) {
            showNotice(
                "Cannot launch",
                listOf(
                    if (entry == null) "Runtime \"$runtimeId\" is not installed. Install it again on the Runtimes tab."
                    else "Runtime \"$runtimeId\" is unusable: ${entry.problem}",
                ),
            )
            return
        }
        if (prefix != null) {
            if (job is WineJob.InitPrefix && c.sessions.isPrefixBusy(prefix.id)) {
                showNotice("Cannot initialize", listOf("Processes are still running in this environment. Stop them first."))
                return
            }
            if (job !is WineJob.InitPrefix && !prefix.initialized) {
                showNotice("Environment not initialized", listOf("Initialize \"${prefix.name}\" on the Environments tab before running anything in it."))
                return
            }
        }

        val home = if (prefix != null) File(File(c.paths.prefixes, prefix.id), "home") else c.paths.home
        home.mkdirs()
        c.paths.tmp.mkdirs()
        val wineDir = prefix?.let { c.prefixes.wineDir(it.id).also { d -> d.mkdirs() } }

        val settings = prefix?.settings ?: PrefixSettings()
        val spec = DisplaySpec.parse(settings.display)
        val reachable = spec != null && LaunchPlanner.needsDisplay(job) && DisplayProbe.isReachable(spec)

        val ctx = PlanContext(
            runtime = manifest,
            runtimeDir = entry.dir,
            prefixDir = wineDir,
            prefixSettings = settings,
            homeDir = home,
            tmpDir = c.paths.tmp,
            deviceAbis = c.deviceAbis,
            displayReachable = reachable,
        )

        when (val result = LaunchPlanner.plan(job, ctx)) {
            is PlanResult.Blocked -> showNotice("Cannot launch", result.reasons)
            is PlanResult.Ready -> {
                val id = c.sessions.start(result.plan, prefix?.id, result.warnings) { info -> onSessionFinished(job, prefix, info) }
                _openSession.value = id
                _tab.value = Tab.SESSIONS
            }
        }
    }

    private fun onSessionFinished(job: WineJob, prefix: PrefixConfig?, info: SessionInfo) {
        if (job is WineJob.InitPrefix && prefix != null) {
            // "Initialized" is recorded only if wineboot succeeded AND Wine really wrote its registry.
            val wroteRegistry = File(c.prefixes.wineDir(prefix.id), "system.reg").isFile
            val ok = info.status == SessionStatus.EXITED && info.exitCode == 0 && wroteRegistry
            val reason = when {
                info.status == SessionStatus.FAILED_TO_START -> "The process could not be started: ${info.detail ?: "unknown error"}"
                info.status == SessionStatus.STOPPED -> "Initialization was stopped before it finished."
                info.exitCode != 0 -> "wineboot exited with code ${info.exitCode}."
                else -> "wineboot exited normally but Wine did not create system.reg."
            }
            c.prefixes.markInitialized(prefix.id, ok, if (ok) null else reason)
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Sessions
    // ---------------------------------------------------------------------------------------------

    fun stopSession(id: String) = c.sessions.stop(id)

    fun clearFinishedSessions() {
        _openSession.value = null
        c.sessions.clearFinished()
    }

    fun logFlow(id: String): StateFlow<List<String>>? = c.sessions.logFlow(id)

    /** Reads the end of a session log off the main thread and hands it to [onReady] on the main thread. */
    fun loadLogForSharing(id: String, onReady: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val text = c.sessions.readLogTail(id, 100 * 1024)
            withContext(Dispatchers.Main) { onReady(text) }
        }
    }
}
