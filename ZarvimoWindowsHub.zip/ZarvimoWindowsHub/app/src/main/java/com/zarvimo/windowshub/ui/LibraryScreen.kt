package com.zarvimo.windowshub.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zarvimo.windowshub.MainViewModel
import com.zarvimo.windowshub.core.ByteFormat
import com.zarvimo.windowshub.core.FileKind
import com.zarvimo.windowshub.data.ItemSource
import com.zarvimo.windowshub.data.LibraryItem

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val items by vm.library.collectAsStateWithLifecycle()
    val prefixes by vm.prefixes.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> vm.importFiles(uris) }

    var runTarget by remember { mutableStateOf<LibraryItem?>(null) }
    var renameTarget by remember { mutableStateOf<LibraryItem?>(null) }
    var removeTarget by remember { mutableStateOf<LibraryItem?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Library", "Windows installers and programs stored privately inside this app.") {
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import EXE / MSI") }
        }
        if (items.isEmpty()) {
            InfoCard(
                "Nothing imported yet",
                "Import a .exe or .msi file. Zarvimo copies it into private app storage and reads its real file headers " +
                    "(file type, CPU architecture, subsystem). Files that are not Windows executables or installers are refused.",
            )
        } else {
            LazyColumn(contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(items, key = { it.id }) { item ->
                    LibraryCard(
                        item = item,
                        prefixName = prefixes.firstOrNull { it.id == item.prefixId }?.name,
                        onRun = { runTarget = item },
                        onRename = { renameTarget = item },
                        onRemove = { removeTarget = item },
                    )
                }
            }
        }
    }

    runTarget?.let { item ->
        RunDialog(vm, item, onDismiss = { runTarget = null })
    }
    renameTarget?.let { item ->
        var text by remember(item.id) { mutableStateOf(item.displayName) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        vm.renameItem(item.id, text)
                        renameTarget = null
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } },
        )
    }
    removeTarget?.let { item ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text("Remove \"${item.displayName}\"?") },
            text = {
                Text(
                    if (item.source == ItemSource.IMPORTED) "The imported copy is deleted from app storage. Programs already installed by it are not touched."
                    else "Only the library entry is removed. The program stays inside its environment.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeItem(item.id)
                    removeTarget = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { removeTarget = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun LibraryCard(
    item: LibraryItem,
    prefixName: String?,
    onRun: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(item.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(item.fileName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Tag(item.kind.label)
                item.machine?.let { Tag(it.label) }
                if (item.kind == FileKind.PE_EXECUTABLE) Tag(item.subsystem.label)
                if (item.isDotNet) Tag(".NET", warn = true)
            }
            KeyValue("Size", ByteFormat.human(item.sizeBytes))
            KeyValue("SHA-256", item.sha256.take(16) + "…")
            if (item.source == ItemSource.PREFIX) KeyValue("Lives in", "environment " + (prefixName ?: "(deleted)"))
            item.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onRun) { Text(if (item.kind == FileKind.MSI) "Install…" else "Run…") }
                OutlinedButton(onClick = onRename) { Text("Rename") }
                TextButton(onClick = onRemove) { Text("Remove") }
            }
        }
    }
}

@Composable
private fun RunDialog(vm: MainViewModel, item: LibraryItem, onDismiss: () -> Unit) {
    val prefixes by vm.prefixes.collectAsStateWithLifecycle()
    val runtimes by vm.runtimes.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf(item.prefixId) }
    var args by remember { mutableStateOf("") }
    var quiet by remember { mutableStateOf(false) }
    val isMsi = item.kind == FileKind.MSI

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isMsi) "Install in which environment?" else "Run in which environment?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (prefixes.isEmpty()) {
                    Text("There are no environments yet. Create one on the Environments tab (this needs an installed runtime).")
                }
                prefixes.forEach { p ->
                    val runtime = runtimes.firstOrNull { it.id == p.runtimeId }?.manifest
                    RadioRow(selected == p.id, { selected = p.id }) {
                        Text(p.name, fontWeight = FontWeight.Medium)
                        Text(
                            (runtime?.name ?: "runtime missing") + if (p.initialized) "" else " · not initialized",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (selected == p.id && !isMsi && runtime != null) {
                            val m = item.machine
                            val supported = m != null && m in runtime.windowsMachines
                            Text(
                                if (supported) "The runtime declares support for ${m?.label}. Whether this program actually works is not known until you try."
                                else "This runtime does not declare support for ${m?.label ?: "this program's CPU type"}; launch will be refused.",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (supported) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
                if (isMsi) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(quiet, { quiet = it })
                        Text("Quiet install (/qn, no windows)")
                    }
                }
                OutlinedTextField(
                    value = args,
                    onValueChange = { args = it },
                    label = { Text(if (isMsi) "Extra msiexec properties" else "Arguments") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected != null && prefixes.any { it.id == selected },
                onClick = {
                    val p = selected ?: return@TextButton
                    if (isMsi) vm.installMsi(item, p, quiet, args) else vm.runProgram(item, p, args)
                    onDismiss()
                },
            ) { Text(if (isMsi) "Install" else "Run") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
