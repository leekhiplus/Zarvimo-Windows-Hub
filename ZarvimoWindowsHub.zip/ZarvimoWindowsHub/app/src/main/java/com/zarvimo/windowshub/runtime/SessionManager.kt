package com.zarvimo.windowshub.runtime

import com.zarvimo.windowshub.core.LaunchPlan
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

enum class SessionStatus { RUNNING, EXITED, STOPPED, FAILED_TO_START }

data class SessionInfo(
    val id: String,
    val title: String,
    val commandLine: String,
    val prefixId: String?,
    val startedAt: Long,
    val endedAt: Long?,
    val status: SessionStatus,
    val exitCode: Int?,
    val detail: String?,
)

/**
 * Runs real child processes and records their output. A session is whatever the launch plan says: there is
 * no simulated execution anywhere in this class. If the process cannot be started, the OS error is shown.
 */
class SessionManager(
    private val scope: CoroutineScope,
    private val logDir: File,
) {
    private class Live(val plan: LaunchPlan) {
        @Volatile var process: Process? = null
        @Volatile var stopRequested = false
        val lines = ArrayDeque<String>()
        @Volatile var dirty = false
        val logFlow = MutableStateFlow<List<String>>(emptyList())
    }

    private val infos = MutableStateFlow<List<SessionInfo>>(emptyList())
    val sessions: StateFlow<List<SessionInfo>> = infos.asStateFlow()

    private val active = MutableStateFlow(0)
    val activeCount: StateFlow<Int> = active.asStateFlow()

    private val live = ConcurrentHashMap<String, Live>()
    private val counter = AtomicInteger(0)

    /**
     * Starts [plan] in the background and returns the session id immediately.
     * @param notes extra lines written at the top of the log (warnings from the launch planner)
     * @param onFinished called on a background thread once the process has ended or failed to start
     */
    fun start(
        plan: LaunchPlan,
        prefixId: String?,
        notes: List<String> = emptyList(),
        onFinished: (SessionInfo) -> Unit = {},
    ): String {
        val id = "s${System.currentTimeMillis().toString(36)}${counter.incrementAndGet()}"
        val info = SessionInfo(
            id = id,
            title = plan.title,
            commandLine = plan.command.joinToString(" ") { if (it.any(Char::isWhitespace) || it.isEmpty()) "\"$it\"" else it },
            prefixId = prefixId,
            startedAt = System.currentTimeMillis(),
            endedAt = null,
            status = SessionStatus.RUNNING,
            exitCode = null,
            detail = null,
        )
        val l = Live(plan)
        live[id] = l
        publish(info)
        trimFinished()
        scope.launch(Dispatchers.IO) { runSession(l, info, notes, onFinished) }
        return id
    }

    fun stop(id: String) {
        val l = live[id] ?: return
        if (infos.value.firstOrNull { it.id == id }?.status != SessionStatus.RUNNING) return
        l.stopRequested = true
        scope.launch(Dispatchers.IO) {
            l.plan.stopCommand?.let { runStopCommand(l) }
            val p = l.process
            p?.destroy()
            delay(3000)
            if (p != null && p.isAlive) p.destroyForcibly()
        }
    }

    fun stopAll() {
        infos.value.filter { it.status == SessionStatus.RUNNING }.forEach { stop(it.id) }
    }

    fun stopForPrefix(prefixId: String) {
        infos.value.filter { it.status == SessionStatus.RUNNING && it.prefixId == prefixId }.forEach { stop(it.id) }
    }

    fun isPrefixBusy(prefixId: String): Boolean =
        infos.value.any { it.status == SessionStatus.RUNNING && it.prefixId == prefixId }

    fun logFlow(id: String): StateFlow<List<String>>? = live[id]?.logFlow

    /** The last [maxBytes] of the session's log file, for sharing. */
    fun readLogTail(id: String, maxBytes: Int = 200 * 1024): String {
        val file = File(logDir, "$id.log")
        if (!file.isFile) return ""
        RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val start = maxOf(0L, len - maxBytes)
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            return String(buf, Charsets.UTF_8)
        }
    }

    fun clearFinished() {
        val finished = infos.value.filter { it.status != SessionStatus.RUNNING }
        finished.forEach {
            live.remove(it.id)
            File(logDir, "${it.id}.log").delete()
        }
        infos.update { list -> list.filter { it.status == SessionStatus.RUNNING } }
    }

    /** Keeps only the newest log files on disk (called once at startup). */
    fun pruneLogs(keep: Int = 30) {
        val files = logDir.listFiles { f -> f.isFile && f.name.endsWith(".log") } ?: return
        files.sortedByDescending { it.lastModified() }.drop(keep).forEach { it.delete() }
    }

    // ---------------------------------------------------------------------------------------------

    private suspend fun runSession(l: Live, initial: SessionInfo, notes: List<String>, onFinished: (SessionInfo) -> Unit) {
        logDir.mkdirs()
        val writer: BufferedWriter? = try {
            File(logDir, "${initial.id}.log").bufferedWriter()
        } catch (_: IOException) {
            null
        }

        var closed = false

        fun append(line: String) {
            if (closed) return
            synchronized(l) {
                l.lines.addLast(line)
                while (l.lines.size > MAX_LINES) l.lines.removeFirst()
                l.dirty = true
            }
            try {
                writer?.write(line)
                writer?.write("\n")
            } catch (_: IOException) {
            }
        }

        fun flushLog() {
            publishLog(l)
            try {
                writer?.flush()
            } catch (_: IOException) {
            }
        }

        append("$ ${initial.commandLine}")
        append("# working directory: ${l.plan.workingDir.absolutePath}")
        notes.forEach { append("# note: $it") }

        val ticker: Job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(250)
                flushLog()
            }
        }

        var finalStatus: SessionStatus
        var exitCode: Int? = null
        var detail: String? = null

        try {
            val pb = ProcessBuilder(l.plan.command)
            pb.directory(l.plan.workingDir)
            pb.redirectErrorStream(true)
            val env = pb.environment()
            env.clear()
            env.putAll(l.plan.environment)

            val process = try {
                pb.start()
            } catch (e: IOException) {
                null.also { detail = explainStartFailure(e) }
            }

            if (process == null) {
                finalStatus = SessionStatus.FAILED_TO_START
                append("! Could not start the process: $detail")
            } else {
                l.process = process
                try {
                    process.outputStream.close() // no stdin is provided
                } catch (_: IOException) {
                }

                // A plain daemon thread, not a coroutine: reading a pipe blocks and cannot be cancelled. If a
                // background process (for example wineserver) keeps the pipe open after the main process
                // ends, this thread is simply left behind instead of hanging the session.
                val reader = Thread {
                    try {
                        val br = BufferedReader(InputStreamReader(process.inputStream, Charsets.UTF_8))
                        while (true) {
                            val line = readBoundedLine(br) ?: break
                            append(line)
                        }
                    } catch (_: IOException) {
                        // stream closed
                    }
                }
                reader.isDaemon = true
                reader.name = "zarvimo-reader-${initial.id}"
                reader.start()

                exitCode = process.waitFor()
                reader.join(1500)
                if (reader.isAlive) {
                    append("# note: a background process still holds the output pipe; later output from it is not captured.")
                }
                finalStatus = if (l.stopRequested) SessionStatus.STOPPED else SessionStatus.EXITED
                append("# process ended with exit code $exitCode" + if (l.stopRequested) " (stopped by user)" else "")
            }
        } catch (e: Exception) {
            finalStatus = SessionStatus.FAILED_TO_START
            detail = e.message ?: e.javaClass.simpleName
            append("! Unexpected error: $detail")
        } finally {
            ticker.cancel()
        }

        flushLog()
        closed = true
        try {
            writer?.close()
        } catch (_: IOException) {
        }

        val done = initial.copy(endedAt = System.currentTimeMillis(), status = finalStatus, exitCode = exitCode, detail = detail)
        publish(done)
        try {
            onFinished(done)
        } catch (_: Exception) {
        }
    }

    private fun runStopCommand(l: Live) {
        val cmd = l.plan.stopCommand ?: return
        try {
            val pb = ProcessBuilder(cmd)
            pb.directory(l.plan.workingDir)
            pb.redirectErrorStream(true)
            pb.environment().apply {
                clear()
                putAll(l.plan.environment)
            }
            val p = pb.start()
            p.outputStream.close()
            if (!p.waitFor(5, TimeUnit.SECONDS)) p.destroyForcibly()
        } catch (_: IOException) {
            // The normal destroy() path below still runs.
        }
    }

    private fun explainStartFailure(e: IOException): String {
        val m = e.message ?: "I/O error"
        return when {
            m.contains("error=13") ->
                "$m. Android blocked executing this file (permission denied). Check the executable bit, and run the environment check on the Runtimes tab."
            m.contains("error=2") ->
                "$m. A file the command needs does not exist; for scripts this often means the interpreter named in the first line is missing."
            m.contains("error=8") ->
                "$m. Exec format error: the binary is for a different CPU architecture than this device."
            else -> m
        }
    }

    private fun readBoundedLine(r: BufferedReader): String? {
        val sb = StringBuilder()
        while (true) {
            val c = r.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(c.toChar())
            if (sb.length >= MAX_LINE_CHARS) return sb.toString()
        }
    }

    private fun publishLog(l: Live) {
        if (!l.dirty) return
        val snapshot: List<String>
        synchronized(l) {
            snapshot = ArrayList(l.lines)
            l.dirty = false
        }
        l.logFlow.value = snapshot
    }

    private fun publish(info: SessionInfo) {
        infos.update { list ->
            val idx = list.indexOfFirst { it.id == info.id }
            if (idx >= 0) list.toMutableList().also { it[idx] = info } else list + info
        }
        active.value = infos.value.count { it.status == SessionStatus.RUNNING }
    }

    private fun trimFinished() {
        val finished = infos.value.filter { it.status != SessionStatus.RUNNING }.sortedBy { it.startedAt }
        if (finished.size <= MAX_FINISHED) return
        val drop = finished.take(finished.size - MAX_FINISHED).map { it.id }.toSet()
        drop.forEach {
            live.remove(it)
            File(logDir, "$it.log").delete()
        }
        infos.update { list -> list.filter { it.id !in drop } }
    }

    private companion object {
        const val MAX_LINES = 4000
        const val MAX_LINE_CHARS = 4000
        const val MAX_FINISHED = 20
    }
}
