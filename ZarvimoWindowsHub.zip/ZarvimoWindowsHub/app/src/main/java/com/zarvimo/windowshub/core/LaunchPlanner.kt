package com.zarvimo.windowshub.core

import java.io.File

enum class WineTool(val exe: String, val label: String) {
    WINECFG("winecfg", "Wine configuration"),
    REGEDIT("regedit", "Registry editor"),
}

/** Something to run through Wine. */
sealed interface WineJob {
    data class RunProgram(val file: File, val inspection: FileInspection, val args: List<String>) : WineJob
    data class InstallMsi(val file: File, val quiet: Boolean, val extraArgs: List<String>) : WineJob
    data object InitPrefix : WineJob
    data object VersionCheck : WineJob
    data class RunTool(val tool: WineTool) : WineJob
}

data class PrefixSettings(
    /** TCP X11 display such as "127.0.0.1:0". Empty means none configured. */
    val display: String = "",
    val winedebug: String = "-all",
    val extraEnv: Map<String, String> = emptyMap(),
)

data class PlanContext(
    val runtime: RuntimeManifest,
    val runtimeDir: File,
    /** The WINEPREFIX directory, or null for jobs that do not use one (version check). */
    val prefixDir: File?,
    val prefixSettings: PrefixSettings,
    val homeDir: File,
    val tmpDir: File,
    val deviceAbis: List<String>,
    /** Result of a TCP probe of the configured display; only meaningful if a display is configured. */
    val displayReachable: Boolean,
)

data class LaunchPlan(
    val title: String,
    val command: List<String>,
    val environment: Map<String, String>,
    val workingDir: File,
    val stopCommand: List<String>?,
)

sealed interface PlanResult {
    data class Ready(val plan: LaunchPlan, val warnings: List<String>) : PlanResult
    data class Blocked(val reasons: List<String>) : PlanResult
}

/**
 * Turns a job into a concrete command line, or explains precisely why it cannot be launched.
 * Every refusal is based on a real check (device ABI, runtime manifest, PE header, display reachability,
 * runtime files on disk). Nothing is assumed to work.
 */
object LaunchPlanner {

    fun needsDisplay(job: WineJob): Boolean = when (job) {
        is WineJob.RunProgram -> job.inspection.subsystem != WinSubsystem.CONSOLE
        is WineJob.InstallMsi -> !job.quiet
        WineJob.InitPrefix -> false
        WineJob.VersionCheck -> false
        is WineJob.RunTool -> true
    }

    fun plan(job: WineJob, ctx: PlanContext): PlanResult {
        val reasons = ArrayList<String>()
        val warnings = ArrayList<String>()
        val rt = ctx.runtime

        // 1. The runtime's native executables must match the device.
        if (rt.hostAbi !in ctx.deviceAbis) {
            reasons.add(
                "Runtime \"${rt.name}\" contains ${rt.hostAbi} binaries, but this device supports: ${ctx.deviceAbis.joinToString()}.",
            )
        }

        // 2. Job-specific checks.
        val wineArgs: List<String>
        val title: String
        var workDir: File = ctx.homeDir
        var protectedEnv: Map<String, String> = emptyMap()

        when (job) {
            is WineJob.RunProgram -> {
                title = "Run ${job.file.name}"
                workDir = job.file.parentFile ?: ctx.homeDir
                val insp = job.inspection
                when (insp.kind) {
                    FileKind.PE_EXECUTABLE -> {}
                    FileKind.PE_DLL -> reasons.add("DLL libraries cannot be launched on their own.")
                    FileKind.MSI -> reasons.add("MSI packages are installed with the Install action, not run directly.")
                    FileKind.UNKNOWN -> reasons.add("This file is not a recognised Windows executable.")
                }
                if (insp.kind == FileKind.PE_EXECUTABLE) {
                    val m = insp.machine
                    if (m == null || m !in rt.windowsMachines) {
                        reasons.add(
                            "This program is ${m?.label ?: "of unknown CPU type"}, but runtime \"${rt.name}\" supports only: " +
                                rt.windowsMachines.joinToString { it.label } + ".",
                        )
                    }
                    if (insp.isDotNet) warnings.add("This is a .NET program. It needs Wine Mono (or a .NET runtime) in the prefix; Zarvimo cannot check that.")
                    if (insp.subsystem == WinSubsystem.NATIVE || insp.subsystem == WinSubsystem.OTHER) {
                        warnings.add("Unusual PE subsystem (${insp.subsystem.label}); it may not start.")
                    }
                }
                wineArgs = listOf(job.file.absolutePath) + job.args
            }

            is WineJob.InstallMsi -> {
                title = "Install ${job.file.name}"
                workDir = job.file.parentFile ?: ctx.homeDir
                if (!job.file.name.endsWith(".msi", ignoreCase = true)) reasons.add("Not an .msi file.")
                warnings.add("MSI architecture is not inspected; the package may refuse to install on this runtime.")
                wineArgs = buildList {
                    add("msiexec")
                    add("/i")
                    add(WindowsPath.fromUnix(job.file.absolutePath))
                    if (job.quiet) add("/qn")
                    addAll(job.extraArgs)
                }
            }

            WineJob.InitPrefix -> {
                title = "Initialize prefix"
                wineArgs = listOf("wineboot", "--init")
                // Skips the Mono/Gecko download prompts, which need a display and network access.
                protectedEnv = mapOf("WINEDLLOVERRIDES" to "mscoree,mshtml=")
                warnings.add("Wine Mono/Gecko are not installed by prefix initialization; .NET and embedded-browser programs need them added separately.")
            }

            WineJob.VersionCheck -> {
                title = "Check Wine version"
                wineArgs = listOf("--version")
            }

            is WineJob.RunTool -> {
                title = job.tool.label
                wineArgs = listOf(job.tool.exe)
            }
        }

        // 3. Display requirement.
        var displayEnv: String? = null
        val spec = DisplaySpec.parse(ctx.prefixSettings.display)
        if (spec != null) displayEnv = spec.envValue
        if (needsDisplay(job)) {
            when {
                ctx.prefixSettings.display.isBlank() ->
                    reasons.add("This needs a graphical display, but no X11 display is configured for the environment. Zarvimo has no built-in X server.")
                spec == null ->
                    reasons.add("The configured display \"${ctx.prefixSettings.display}\" is not valid. Use host:number, e.g. 127.0.0.1:0 (TCP only).")
                !ctx.displayReachable ->
                    reasons.add("Nothing is listening for X11 at ${spec.host}:${spec.port}. Start an X server app that accepts TCP connections first.")
            }
        }

        // 4. Build the command from the runtime template.
        val tokens = HashMap<String, String>()
        tokens["runtime"] = ctx.runtimeDir.absolutePath
        tokens["home"] = ctx.homeDir.absolutePath
        tokens["tmp"] = ctx.tmpDir.absolutePath
        ctx.prefixDir?.let { tokens["prefix"] = it.absolutePath }

        var command: List<String> = emptyList()
        var stop: List<String>? = null
        val env = LinkedHashMap<String, String>()
        try {
            command = CommandTemplate.expand(rt.command, tokens, wineArgs)
            stop = rt.stopCommand?.let { CommandTemplate.expand(it, tokens, emptyList()) }

            env["HOME"] = ctx.homeDir.absolutePath
            env["TMPDIR"] = ctx.tmpDir.absolutePath
            env["PATH"] = ctx.runtimeDir.absolutePath + "/bin:/system/bin"
            env["LANG"] = "C.UTF-8"
            ctx.prefixDir?.let { env["WINEPREFIX"] = it.absolutePath }
            env["WINEDEBUG"] = ctx.prefixSettings.winedebug
            displayEnv?.let { env["DISPLAY"] = it }
            for ((k, v) in rt.env) env[k] = CommandTemplate.expandString(v, tokens)
            env.putAll(protectedEnv)
            env.putAll(ctx.prefixSettings.extraEnv)
        } catch (e: IllegalArgumentException) {
            reasons.add(e.message ?: "Invalid runtime command template.")
        }

        // 5. The runtime's executable must really exist on disk.
        if (command.isNotEmpty()) {
            val exe = File(command[0])
            when {
                !exe.isFile -> reasons.add("Runtime executable is missing: ${exe.path}")
                !exe.canExecute() -> reasons.add("Runtime executable is not marked executable: ${exe.path}")
            }
        }

        if (reasons.isNotEmpty()) return PlanResult.Blocked(reasons)
        return PlanResult.Ready(LaunchPlan(title, command, env, workDir, stop), warnings)
    }
}
