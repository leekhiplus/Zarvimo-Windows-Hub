package com.zarvimo.windowshub.data

import com.zarvimo.windowshub.core.ArchiveExtractor
import com.zarvimo.windowshub.core.FsUtil
import com.zarvimo.windowshub.core.ManifestException
import com.zarvimo.windowshub.core.RuntimeManifest
import com.zarvimo.windowshub.core.RuntimeManifestParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files

/** An installed runtime folder. [manifest] is null if the folder could not be read; [problem] says why. */
data class RuntimeEntry(
    val id: String,
    val dir: File,
    val manifest: RuntimeManifest?,
    val problem: String?,
    val sizeBytes: Long,
)

class RuntimeImportException(message: String) : Exception(message)

class RuntimeRepository(
    private val paths: AppPaths,
    private val deviceAbis: List<String>,
) {
    private val lock = Any()
    private val state = MutableStateFlow<List<RuntimeEntry>>(emptyList())
    val runtimes: StateFlow<List<RuntimeEntry>> = state.asStateFlow()

    fun load() = synchronized(lock) {
        FsUtil.deleteTreeNoFollow(paths.staging) // leftovers of interrupted imports
        state.value = scan()
    }

    fun find(id: String): RuntimeEntry? = state.value.firstOrNull { it.id == id }

    private fun scan(): List<RuntimeEntry> {
        val dirs = paths.runtimes.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: return emptyList()
        return dirs.sortedBy { it.name }.map { dir ->
            val manifestFile = File(dir, RuntimeManifest.FILE_NAME)
            var manifest: RuntimeManifest? = null
            var problem: String? = null
            try {
                manifest = RuntimeManifestParser.parse(manifestFile.readText())
                if (manifest.id != dir.name) problem = "Manifest id \"${manifest.id}\" does not match its folder."
            } catch (e: ManifestException) {
                problem = e.message
            } catch (e: IOException) {
                problem = "Cannot read ${RuntimeManifest.FILE_NAME}: ${e.message}"
            }
            RuntimeEntry(dir.name, dir, if (problem == null) manifest else null, problem, dirSize(dir))
        }
    }

    /**
     * Extracts a runtime package, validates its manifest and the files it names, and installs it.
     * Nothing is installed unless every check passes.
     */
    fun install(
        open: () -> InputStream,
        archiveSize: Long,
        progress: (entries: Int, bytes: Long) -> Unit,
        checkCancelled: () -> Unit,
    ): RuntimeManifest {
        if (archiveSize > 0 && paths.runtimes.usableSpace < archiveSize * 2) {
            throw RuntimeImportException("Not enough free storage. The extracted runtime needs more space than the archive itself.")
        }
        paths.staging.mkdirs()
        val staging = File(paths.staging, newId())
        try {
            open().use { input ->
                ArchiveExtractor(AndroidFileOps).extract(input, staging, paths.tmp, progress, checkCancelled)
            }

            val manifestFile = File(staging, RuntimeManifest.FILE_NAME)
            if (!manifestFile.isFile) {
                throw RuntimeImportException(
                    "${RuntimeManifest.FILE_NAME} was not found at the top level of the archive. " +
                        "This is not a Zarvimo runtime package (see docs/RUNTIME_FORMAT.md).",
                )
            }
            val manifest = try {
                RuntimeManifestParser.parse(manifestFile.readText())
            } catch (e: ManifestException) {
                throw RuntimeImportException(e.message ?: "Invalid manifest.")
            }

            if (manifest.hostAbi !in deviceAbis) {
                throw RuntimeImportException(
                    "This runtime contains ${manifest.hostAbi} binaries, but this device supports: ${deviceAbis.joinToString()}. It can never run here.",
                )
            }

            for (rel in manifest.executables) {
                val f = FsUtil.resolveInside(staging, rel)
                if (f == null || !f.isFile) throw RuntimeImportException("Listed executable \"$rel\" is not in the package.")
                AndroidFileOps.chmod(f, 0x1ED) // 0755
            }

            val entryRel = manifest.command[0].removePrefix("{runtime}/")
            val entry = FsUtil.resolveInside(staging, entryRel)
            if (entry == null || !entry.isFile) {
                throw RuntimeImportException("The command's executable \"$entryRel\" is not in the package (it must be a real file, not a link to a path outside the package).")
            }
            if (!entry.canExecute()) {
                throw RuntimeImportException("The command's executable \"$entryRel\" is not executable. Mark it executable in the archive or list it under \"executables\".")
            }

            synchronized(lock) {
                val finalDir = File(paths.runtimes, manifest.id)
                if (finalDir.exists()) {
                    throw RuntimeImportException("A runtime with id \"${manifest.id}\" is already installed. Remove it first to replace it.")
                }
                Files.move(staging.toPath(), finalDir.toPath())
                state.value = scan()
            }
            return manifest
        } catch (t: Throwable) {
            FsUtil.deleteTreeNoFollow(staging)
            throw t
        }
    }

    fun remove(id: String) = synchronized(lock) {
        val dir = File(paths.runtimes, id)
        if (dir.parentFile?.canonicalFile == paths.runtimes.canonicalFile) FsUtil.deleteTreeNoFollow(dir)
        state.value = scan()
    }

    private fun dirSize(dir: File): Long {
        var total = 0L
        val stack = ArrayDeque<File>()
        stack.add(dir)
        while (stack.isNotEmpty()) {
            val d = stack.removeLast()
            val children = d.listFiles() ?: continue
            for (c in children) {
                if (FsUtil.isSymlink(c)) continue
                if (c.isDirectory) stack.add(c) else total += c.length()
            }
        }
        return total
    }
}
