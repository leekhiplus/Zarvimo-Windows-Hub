package com.zarvimo.windowshub.core

class ManifestException(message: String) : Exception(message)

/**
 * "Zarvimo runtime package" manifest (format version 1), stored as zarvimo-runtime.json at the archive root.
 * See docs/RUNTIME_FORMAT.md.
 */
data class RuntimeManifest(
    val formatVersion: Int,
    val id: String,
    val name: String,
    val version: String,
    val wineVersion: String,
    /** Android ABI of the native executables that the command starts (e.g. arm64-v8a). */
    val hostAbi: String,
    /** Windows CPU architectures this Wine build (plus any translation layer) can run. */
    val windowsMachines: Set<WinMachine>,
    /** Informational label for any CPU translation layer in use, e.g. "box64". Null if none. */
    val translation: String?,
    val command: List<String>,
    val stopCommand: List<String>?,
    val env: Map<String, String>,
    /** Relative paths that are made executable after extraction (needed for zip packages). */
    val executables: List<String>,
    val description: String?,
    val licenseNotes: String?,
) {
    companion object {
        const val FILE_NAME = "zarvimo-runtime.json"
        const val SUPPORTED_FORMAT = 1
        val VALID_ABIS = setOf("arm64-v8a", "x86_64", "armeabi-v7a", "x86")
        val ID_REGEX = Regex("^[a-z0-9][a-z0-9._-]{0,63}$")
        val ENV_KEY_REGEX = Regex("^[A-Za-z_][A-Za-z0-9_]*$")
    }
}

object RuntimeManifestParser {
    fun parse(text: String): RuntimeManifest {
        val root = try {
            MiniJson.parseObject(text)
        } catch (e: JsonException) {
            throw ManifestException("${RuntimeManifest.FILE_NAME} is not valid JSON: ${e.message}")
        }

        val formatVersion = root.optLong("formatVersion", -1).toInt()
        if (formatVersion != RuntimeManifest.SUPPORTED_FORMAT) {
            throw ManifestException("Unsupported formatVersion $formatVersion (this app reads version ${RuntimeManifest.SUPPORTED_FORMAT}).")
        }

        val id = reqString(root, "id")
        if (!RuntimeManifest.ID_REGEX.matches(id)) {
            throw ManifestException("\"id\" must be 1-64 characters of a-z, 0-9, '.', '_' or '-' and start with a letter or digit.")
        }
        val name = reqString(root, "name").take(80)
        val version = reqString(root, "version").take(40)
        val wineVersion = reqString(root, "wineVersion").take(40)

        val hostAbi = reqString(root, "hostAbi")
        if (hostAbi !in RuntimeManifest.VALID_ABIS) {
            throw ManifestException("\"hostAbi\" must be one of ${RuntimeManifest.VALID_ABIS.joinToString()}.")
        }

        val machinesRaw = root.optList("windowsMachines")
            ?: throw ManifestException("\"windowsMachines\" is required (list of \"x86\", \"x64\", \"arm64\").")
        val machines = LinkedHashSet<WinMachine>()
        for (m in machinesRaw) {
            val s = m as? String ?: throw ManifestException("\"windowsMachines\" entries must be strings.")
            val machine = WinMachine.fromManifestName(s)
                ?: throw ManifestException("Unknown windowsMachines entry \"$s\" (allowed: x86, x64, arm64).")
            machines.add(machine)
        }
        if (machines.isEmpty()) throw ManifestException("\"windowsMachines\" must not be empty.")

        val command = stringList(root, "command") ?: throw ManifestException("\"command\" is required.")
        validateCommand(command, requireWineArgs = true, field = "command")

        val stop = stringList(root, "stopCommand")
        if (stop != null) validateCommand(stop, requireWineArgs = false, field = "stopCommand")

        val envMap = LinkedHashMap<String, String>()
        val envRaw = root.optMap("env")
        if (envRaw != null) {
            for ((k, v) in envRaw) {
                if (!RuntimeManifest.ENV_KEY_REGEX.matches(k)) throw ManifestException("Invalid environment variable name \"$k\".")
                envMap[k] = v as? String ?: throw ManifestException("Environment variable \"$k\" must be a string.")
            }
        }

        val executables = stringList(root, "executables") ?: emptyList()
        for (e in executables) {
            if (FsUtil.normalizeEntryName(e).isNullOrEmpty()) {
                throw ManifestException("\"executables\" entry \"$e\" must be a relative path inside the package.")
            }
        }

        return RuntimeManifest(
            formatVersion = formatVersion,
            id = id,
            name = name,
            version = version,
            wineVersion = wineVersion,
            hostAbi = hostAbi,
            windowsMachines = machines,
            translation = root.optString("translation")?.take(40)?.ifBlank { null },
            command = command,
            stopCommand = stop,
            env = envMap,
            executables = executables.map { FsUtil.normalizeEntryName(it)!! },
            description = root.optString("description")?.take(500),
            licenseNotes = root.optString("licenseNotes")?.take(2000),
        )
    }

    private fun reqString(map: Map<String, Any?>, key: String): String {
        val v = map[key] as? String
        if (v.isNullOrBlank()) throw ManifestException("\"$key\" is required and must be a non-empty string.")
        return v
    }

    private fun stringList(map: Map<String, Any?>, key: String): List<String>? {
        val raw = map[key] ?: return null
        val list = raw as? List<*> ?: throw ManifestException("\"$key\" must be a list of strings.")
        return list.map { it as? String ?: throw ManifestException("\"$key\" must contain only strings.") }
    }

    private fun validateCommand(cmd: List<String>, requireWineArgs: Boolean, field: String) {
        if (cmd.isEmpty()) throw ManifestException("\"$field\" must not be empty.")
        if (!cmd[0].startsWith("{runtime}/")) {
            throw ManifestException("\"$field\"[0] must start with \"{runtime}/\" so the launched executable lives inside the runtime package.")
        }
        val wineArgCount = cmd.count { it == CommandTemplate.WINE_ARGS }
        if (requireWineArgs && wineArgCount != 1) {
            throw ManifestException("\"$field\" must contain the element \"{wine-args}\" exactly once.")
        }
        if (!requireWineArgs && wineArgCount != 0) {
            throw ManifestException("\"$field\" must not contain \"{wine-args}\".")
        }
        // Surfaces unknown placeholders at import time rather than at launch time.
        val dummy = mapOf("runtime" to "/r", "prefix" to "/p", "home" to "/h", "tmp" to "/t")
        try {
            CommandTemplate.expand(cmd, dummy, emptyList())
        } catch (e: IllegalArgumentException) {
            throw ManifestException("\"$field\": ${e.message}")
        }
    }
}
