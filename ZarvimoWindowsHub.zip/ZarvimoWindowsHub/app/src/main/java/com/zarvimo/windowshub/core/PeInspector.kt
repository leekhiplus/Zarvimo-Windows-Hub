package com.zarvimo.windowshub.core

import java.io.File
import java.io.RandomAccessFile

enum class FileKind(val label: String) {
    PE_EXECUTABLE("EXE"),
    PE_DLL("DLL"),
    MSI("MSI"),
    UNKNOWN("Unknown"),
}

enum class WinMachine(val label: String, val manifestName: String?) {
    X86("x86 (32-bit)", "x86"),
    X64("x86-64", "x64"),
    ARM64("ARM64", "arm64"),
    ARM("ARM (32-bit)", null),
    OTHER("unrecognised CPU type", null),
    ;

    companion object {
        fun fromManifestName(name: String): WinMachine? = entries.firstOrNull { it.manifestName == name }
    }
}

enum class WinSubsystem(val label: String) {
    GUI("GUI"),
    CONSOLE("Console"),
    NATIVE("Native"),
    OTHER("Other"),
    NONE("n/a"),
}

/** What was actually read from the file's headers. Nothing here is guessed from the file name alone. */
data class FileInspection(
    val kind: FileKind,
    val machine: WinMachine?,
    val subsystem: WinSubsystem,
    val isDotNet: Boolean,
    val notes: List<String>,
)

/** Random-access read abstraction so the parser can be tested without touching the file system. */
interface ByteSource {
    val length: Long

    /** Returns exactly [length] bytes starting at [position], or null if that range is not fully available. */
    fun readAt(position: Long, length: Int): ByteArray?
}

class BytesSource(private val data: ByteArray) : ByteSource {
    override val length: Long get() = data.size.toLong()

    override fun readAt(position: Long, length: Int): ByteArray? {
        if (position < 0 || length < 0 || position + length > data.size) return null
        return data.copyOfRange(position.toInt(), position.toInt() + length)
    }
}

class FileByteSource(private val file: File) : ByteSource {
    override val length: Long get() = file.length()

    override fun readAt(position: Long, length: Int): ByteArray? {
        if (position < 0 || length < 0 || position + length > file.length()) return null
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(position)
            val buf = ByteArray(length)
            var off = 0
            while (off < length) {
                val n = raf.read(buf, off, length - off)
                if (n < 0) return null
                off += n
            }
            return buf
        }
    }
}

/**
 * Reads PE (Portable Executable) and MSI (OLE compound) headers.
 *
 * It identifies what a file *is*. It does not decide whether the file will run: that depends on the
 * Wine runtime, the CPU translation layer and the program itself.
 */
object PeInspector {
    private val OLE_SIGNATURE = byteArrayOf(
        0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte(),
    )

    private const val IMAGE_FILE_DLL = 0x2000
    private const val MAGIC_PE32 = 0x10B
    private const val MAGIC_PE32_PLUS = 0x20B
    private const val CLR_DIRECTORY_INDEX = 14

    fun inspect(file: File): FileInspection = inspect(FileByteSource(file), file.name)

    fun inspect(src: ByteSource, nameHint: String): FileInspection {
        val len = src.length
        if (len < 8) return unknown("File is too small to be a Windows executable or installer.")

        val head = src.readAt(0, minOf(len, 64L).toInt()) ?: return unknown("File could not be read.")

        if (head.size >= 8 && head.copyOfRange(0, 8).contentEquals(OLE_SIGNATURE)) {
            return if (nameHint.endsWith(".msi", ignoreCase = true)) {
                FileInspection(
                    kind = FileKind.MSI,
                    machine = null,
                    subsystem = WinSubsystem.NONE,
                    isDotNet = false,
                    notes = listOf("Windows Installer package. Its target CPU is not inspected by Zarvimo."),
                )
            } else {
                unknown("OLE compound file that is not named .msi (could be a Word document, MSP patch, etc.).")
            }
        }

        if (head.size < 64 || head[0] != 'M'.code.toByte() || head[1] != 'Z'.code.toByte()) {
            return unknown("No MZ/PE header found. This is not a Windows executable.")
        }

        val peOffset = u32(head, 0x3C)
        if (peOffset < 0x40 || peOffset > len - 24) {
            return unknown("MZ header present but the PE header offset is invalid (possibly a 16-bit DOS program).")
        }

        val coffAvailable = minOf(len - peOffset, 24L + 512L).toInt()
        val block = src.readAt(peOffset, coffAvailable) ?: return unknown("PE header could not be read.")
        if (block.size < 24 ||
            block[0] != 'P'.code.toByte() || block[1] != 'E'.code.toByte() || block[2] != 0.toByte() || block[3] != 0.toByte()
        ) {
            return unknown("MZ header present but no PE signature (an older NE/LE/DOS executable).")
        }

        val machineCode = u16(block, 4)
        val sizeOfOptionalHeader = u16(block, 20)
        val characteristics = u16(block, 22)

        if (sizeOfOptionalHeader < 70 || block.size < 24 + 70) {
            return unknown("PE file has no usable optional header.")
        }
        val magic = u16(block, 24)
        val isPlus = when (magic) {
            MAGIC_PE32 -> false
            MAGIC_PE32_PLUS -> true
            else -> return unknown("Unsupported PE optional header magic 0x${magic.toString(16)}.")
        }

        val subsystemCode = u16(block, 24 + 68)
        val subsystem = when (subsystemCode) {
            2 -> WinSubsystem.GUI
            3 -> WinSubsystem.CONSOLE
            1 -> WinSubsystem.NATIVE
            else -> WinSubsystem.OTHER
        }

        val machine = when (machineCode) {
            0x014C -> WinMachine.X86
            0x8664 -> WinMachine.X64
            0xAA64 -> WinMachine.ARM64
            0x01C0, 0x01C4 -> WinMachine.ARM
            else -> WinMachine.OTHER
        }

        // CLR (.NET) data directory.
        val numRvaOffset = 24 + if (isPlus) 108 else 92
        val dirStart = 24 + if (isPlus) 112 else 96
        var dotNet = false
        if (block.size >= numRvaOffset + 4) {
            val numRva = u32(block, numRvaOffset)
            val entry = dirStart + CLR_DIRECTORY_INDEX * 8
            if (numRva > CLR_DIRECTORY_INDEX && block.size >= entry + 8 && sizeOfOptionalHeader >= entry - 24 + 8) {
                dotNet = u32(block, entry) != 0L && u32(block, entry + 4) != 0L
            }
        }

        val notes = ArrayList<String>()
        if (dotNet) notes.add("Managed .NET assembly: needs Wine Mono or a .NET runtime inside the prefix.")
        if (subsystem == WinSubsystem.NATIVE) notes.add("Native-subsystem image (driver or boot program); not a normal user program.")
        if (machine == WinMachine.OTHER) notes.add("CPU type 0x${machineCode.toString(16)} is not one Zarvimo recognises.")

        val kind = if ((characteristics and IMAGE_FILE_DLL) != 0) FileKind.PE_DLL else FileKind.PE_EXECUTABLE
        return FileInspection(kind, machine, subsystem, dotNet, notes)
    }

    private fun unknown(note: String) = FileInspection(FileKind.UNKNOWN, null, WinSubsystem.NONE, false, listOf(note))

    private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or
            ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or
            ((b[o + 3].toLong() and 0xFF) shl 24)
}
