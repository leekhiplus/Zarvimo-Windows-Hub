# Zarvimo runtime package format (version 1)

Zarvimo Windows Hub does **not** contain Wine. It launches a Wine build that you provide, packaged as a
*runtime package*. This document defines that package so you (or a runtime builder) can produce one.

A runtime package is an archive (`.tar.xz`, `.tar.gz`, `.tar.bz2`, `.tar` or `.zip`; the type is detected
from the file's content, not its name) with a manifest file named `zarvimo-runtime.json` at the **top level**.
Zstandard (`.zst`) is not supported.

## Contents

```
zarvimo-runtime.json
bin/box64            # optional CPU translator (ARM64 host running x86/x64 Windows programs)
bin/wine             # whatever your command starts
lib/...              # Wine libraries, loader, dlls, share/wine/..., etc.
```

The package must be built for the **device's CPU architecture** (`hostAbi`), usually `arm64-v8a`.
On Android the C library is Bionic. A Wine built for glibc (a typical Linux distribution build) will not start
unless the package also carries a compatible glibc loader/rootfs and the command starts it explicitly.
Producing such a build is outside the scope of this project.

## Manifest

```json
{
  "formatVersion": 1,
  "id": "wine-9.0-box64-arm64",
  "name": "Wine 9.0 + Box64",
  "version": "1",
  "wineVersion": "9.0",
  "hostAbi": "arm64-v8a",
  "windowsMachines": ["x64", "x86"],
  "translation": "box64",
  "command": ["{runtime}/bin/box64", "{runtime}/bin/wine64", "{wine-args}"],
  "stopCommand": ["{runtime}/bin/box64", "{runtime}/bin/wineserver64", "-k"],
  "env": {
    "LD_LIBRARY_PATH": "{runtime}/lib",
    "BOX64_LD_LIBRARY_PATH": "{runtime}/lib/wine/x86_64-unix",
    "WINEESYNC": "0"
  },
  "executables": ["bin/box64", "bin/wine64", "bin/wineserver64"],
  "description": "Optional text shown in the app.",
  "licenseNotes": "Wine: LGPL-2.1+. Box64: MIT. Source: <where to get it>."
}
```

The paths and variables above are only an illustration of the *shape*. Use whatever your build needs.

| Field | Required | Meaning |
|---|---|---|
| `formatVersion` | yes | Must be `1`. |
| `id` | yes | 1-64 characters: `a-z 0-9 . _ -`, starting with a letter or digit. Also the install folder name. |
| `name`, `version`, `wineVersion` | yes | Display text. |
| `hostAbi` | yes | `arm64-v8a`, `x86_64`, `armeabi-v7a` or `x86`: the Android ABI of the native executables. Import is refused if the device does not support it. |
| `windowsMachines` | yes | Windows program CPU types this runtime can run: `x86` (32-bit), `x64`, `arm64`. Zarvimo refuses to launch programs whose PE header says otherwise. Declare only what you have actually tested. |
| `translation` | no | Informational label such as `box64` or `fex`. Zarvimo does not drive the translator; your `command` does. |
| `command` | yes | Argument vector used to start Wine. `[0]` must begin with `{runtime}/`. Must contain the element `{wine-args}` exactly once, standing alone. |
| `stopCommand` | no | Run when the user presses Stop (before the process is signalled). Typically `wineserver -k`. May not contain `{wine-args}`. |
| `env` | no | Environment variables. Values may use `{runtime}`, `{prefix}`, `{home}`, `{tmp}`. |
| `executables` | no | Relative paths made executable (`chmod 755`) after extraction. Needed for `.zip` packages, which may not carry permission bits. |
| `description`, `licenseNotes` | no | Shown on the Runtimes screen. |

### Placeholders

| Token | Value |
|---|---|
| `{runtime}` | Absolute path of the installed runtime folder. |
| `{prefix}` | The environment's `WINEPREFIX` (only when a job uses one). |
| `{home}` | Per-environment home directory. |
| `{tmp}` | App cache temp directory. |
| `{wine-args}` | Expands to the Wine arguments for the job (see below). |

Unknown placeholders are rejected at import time.

### What `{wine-args}` expands to

| Job | Arguments |
|---|---|
| Run a program | `<absolute path of .exe> <user arguments...>` |
| Install an MSI | `msiexec /i Z:\path\to\file.msi [/qn] [extra properties]` |
| Initialize an environment | `wineboot --init` (with `WINEDLLOVERRIDES=mscoree,mshtml=` so Wine does not prompt for Mono/Gecko) |
| winecfg / regedit | `winecfg` / `regedit` |
| Runtime version check | `--version` |

### Environment variables Zarvimo always sets

`HOME`, `TMPDIR`, `PATH` (`{runtime}/bin:/system/bin`), `LANG`, `WINEPREFIX`, `WINEDEBUG`, and `DISPLAY` when a
valid X11 TCP display is configured. The manifest's `env` is applied on top, then the environment's own
overrides from its Settings screen.

## What Zarvimo validates on import

- The archive is extracted with protection against absolute paths, `..` segments and writes through symbolic
  links that point outside the runtime folder. Device nodes are skipped.
- The manifest parses and every field above is valid.
- `hostAbi` is supported by this device.
- Every `executables` entry exists in the package; the file named by `command[0]` exists, is a real file
  inside the package and is executable.
- Nothing is installed if any check fails.

What it cannot validate: that Wine actually starts, that its libraries are complete, or that the translator works.
The **Run version check** button on a runtime launches `command` with `--version` and shows the real output.

## Display

Windows GUI programs need an X server. Zarvimo has none. Configure an environment's display as `host:N`
(TCP port `6000+N`) and run an Android X server app that accepts TCP connections. Zarvimo checks that something is
listening before launching a graphical job and refuses otherwise. Unix-socket displays cannot be used because
sockets of other apps are not reachable from this app.
